"""Replace all spaces with %20"""
def urlify(input):
    return input.strip().replace(' ', '%20')

print(urlify(' Mr John Smith   '))