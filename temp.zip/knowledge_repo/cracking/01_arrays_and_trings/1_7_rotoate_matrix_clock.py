

def rotate_matrix(M, degrees=90):
  n = len(M)
  M_n = [[-1]*n for _ in range(n)]

  for r in range(n):
    for c in range(n):

      #clockwise 90
      if degrees == 90:
        r_new = c
        c_new = n-1-r

      #counterclockwise 90
      elif degrees == -90:
        r_new = n-1-c
        c_new = r

      M_n[r_new][c_new] = M[r][c]

  return M_n


def rotate_matrix_inpalce(M):
  layer= 0
  layer_size = len(M)
  while layer_size > 1:
    _rotate_layer(M, layer, layer_size)
    layer_size = layer_size - 2
    layer +=1
  return M

def _rotate_layer(M, layer, layer_size):
  dist = layer_size-1

  min, max = layer, layer+dist
  
  while dist > 0:
    start = M[layer][layer]
    cur_cell = (layer, layer)
    prev_cell = (-1,-1)
    while True:
      prev_cell =  _prev_cell(cur_cell, min, max)
      if prev_cell != (layer, layer):
        M[cur_cell[0]][cur_cell[1]] = M[prev_cell[0]][prev_cell[1]]
        cur_cell = prev_cell
      else:
        break

    M[cur_cell[0]][cur_cell[1]] = start
    dist -= 1
  
def _prev_cell(cell, min, max):
  r, c = cell
  if c == min and r < max:
    return r+1, c
  elif c > min and r == min:
    return r, c-1
  elif c == max and r > min:
    return r-1, c
  elif c < max and r == max:
    return r, c+1
  print("ERR")

m = [[1,2,3],
     [4,5,6],
     [7,8,9]]

print(rotate_matrix_inpalce(m))


# == [[7,4,1], [8,5,2], [9,6,3]])