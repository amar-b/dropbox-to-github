"""Determine if two strings are one insert, delete or edit away from each other"""
def one_insert_away(smaller, larger):
  s, l = 0, 0
  jumps = 0
  while s < len(smaller) and l < len(larger):
    if smaller[s] == larger[l]:
      s += 1
      l += 1 
    else:
      l += 1
      jumps += 1
      if jumps > 1:
        return False
  return True

def one_edit_away(s1, s2):
  count = 0
  for i in range(len(s1)):
    if s1[i] != s2[i]:
      count += 1
  return count <= 1

def one_away(s1, s2):
  n1, n2 = len(s1), len(s2)
  if n1 == n2:
    return one_edit_away(s1, s2)
  elif n1+1 == n2:
    return one_insert_away(s1, s2)
  elif n1 == n2+1:
    return one_insert_away(s2, s1)
  return False

print(one_away('pale', 'ple'))
print(one_away('pales', 'pale'))
print(one_away('pale', 'bale'))
print(one_away('pale', 'bake'))
print(one_away('pale', 'bae'))
print(one_away('pale', 'pak'))
print(one_away('pale', 'pxle'))
