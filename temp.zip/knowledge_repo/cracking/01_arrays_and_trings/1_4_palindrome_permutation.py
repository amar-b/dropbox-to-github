"""Check if an input string has a permutation that is a palindrome"""

def not_even_counts(input):
    d = {}
    for s in input:
        s = s.lower()
        if s not in d:
            d[s] = 1
        else:
            d[s] += 1

    cnt = 0
    for val in d.values():
        if val%2 != 0:
            cnt += 1
    return cnt


def has_palindrome(input):
    input = input.replace(' ', '')
    if len(input) == 1:
        return True
    if len(input) == 2:
        return False
    elif len(input)%2 == 0:
        # if input is even all characters need to appear an even amounts of times
        return not_even_counts(input)  == 0
    else:
        # if input is odd then all characters but one (the middle character) need to appear an even amounts of times
        return not_even_counts(input) == 1

print(has_palindrome('Tact Coa'))