def string_compression(string):
  n = len(string)
  if n == 0:
    return ''
  elif n == 1:
    return f'{string}1'

  compressed_str = ''
  ptr = 0
  while ptr < n:
    key = string[ptr]
    count = 1
    ptr += 1
    while ptr < n and key == string[ptr]:
      ptr += 1
      count += 1
    compressed_str += f'{key}{count}'

  return compressed_str
    
print(string_compression('aabcccccaaa'))