""" HINTS: 44, 117, 132 """

"""Determine if a string has all unique characters O(n)"""
def is_unique(str):
    chars = list(str)
    char_set = set()
    for char in chars:
        if char in char_set:
            return False
        else:
            char_set.add(char)
    return True

"""Without an additional data structure O(n*n/2) = O(n^2)
    Look at each unique pair and make sure they are not same
"""
def is_unique_2(str):
    n = len(str)
    for i in range(n):
        for j in range(i+1, len(str)):
            if str[i] == str[j]:
                return False
    return True



print(is_unique_2("ABV"))
print(is_unique_2("ABC"))
print(is_unique_2("ABCB"))
print(is_unique_2(""))