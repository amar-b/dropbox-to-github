"""Check if one string is a perm of another"""
def is_permutation_set(s1, s2):
    x = set(s1)
    y = set(s2)
    return x == y
    
def is_permutation(s1, s2):
    counts = {}
    for c in s1:
        if c not in counts:
            counts[c] = 1
        else:
            counts[c]+=1
    
    for c in s2:
        if c not in counts:
            return False
        else:
            counts[c] -= 1
    
    for val in counts.values():
        if val != 0:
            return False

    return True

print(is_permutation("abc", "bac"))
print(is_permutation("abc", "abd"))
