#n=7
#for x in range(2*n):
	#print(x%n)
	
	
def get_digits(n):
	digits = []
	while n!=0:
		d = n%10
		digits.append(d)
		n= n//10
	digits.reverse()
	return digits
	
print(get_digits(54321))
	

