def is_prime(n):
    if n == 1 or n == 4:
        return False
    if n == 2 or n == 3:
        return True
    else:
        # primer numbers have factors of 1 and themselves
        # so start of range is 2 and end is n/2 since a factor can't be larger than n/2 (unless its n)
        for candidate_factor in range(2, n//2):
            if n % candidate_factor == 0:
                return False # n is not a prime since it has a factor not 1 or itself
        return True
        
if __name__ == '__main__':
    for i in range(1,10):
        print(i, is_prime(i))
