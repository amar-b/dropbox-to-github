def reverse(x):
    sign = -1 if x < 0 else 1  
    num = abs(x)
    mul = 10**(len(str(num))-1)
    res = 0
    
    while num > 0:
        digit = num % 10
        res = res + mul*digit
        num = num//10
        mul = mul//10
        
    res = res * sign
    
    if res >= -2**(31) and res <= (2**31 -1):
        return res
    else:
        return 0