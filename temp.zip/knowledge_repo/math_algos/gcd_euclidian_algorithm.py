""" Finds the gcd of a and b using the euclidian algorithm
    Complexity: O(log min(a, b))
"""
def gcd(a,b):
    if a == 0 or b == 0: # 0 has no factors
        return -1
    if (b>a):
        a, b = b, a
    r =  a%b
    if r == 0:
        return b
    return gcd(a=b, b=r)

if __name__ == "__main__":
    print(gcd(a=10, b=15))