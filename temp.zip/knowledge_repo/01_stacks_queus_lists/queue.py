from collections import deque

"""Queue usuing standard library 'collections.dequeue'
    O(1) enqueue and dequeue
"""
class Queue():
    def __init__(self):
        self.queue = deque()
    
    def enqueue(self, value):
        self.queue.append(value) #add
    
    def dequeue(self):
        if self.is_empty():
            raise Exception("queue is empty")

        return self.queue.popleft() #remove
    
    def peek(self):
        if len(self.queue) == 0:
            raise Exception("queue is empty")

        return self.queue[0]    #peek

    def is_empty(self):
        return len(self.queue) == 0 #empty

class LinkedListQueue():
    class QueueNode:
        def __init__(self, value):
            self.value = value
            self.next = None

    def __init__(self):
        self.first = None #front of queue
        self.last = None #back of queue

    def enqueue(self, item):
        new_node = self.QueueNode(item)

        if self.first == None:
            self.first = new_node
        else:
            self.last.next = new_node #if not first item then point second to last node node to new node

        self.last = new_node    # set new node to be last node

    def dequeue(self):
        if (self.is_empty()):
            raise Exception("queue is empty")
 
        removed_node = self.first
        self.first = removed_node.next
        return removed_node.value

    def peek(self):
        if (self.is_empty()):
            raise Exception("queue is empty")
 
        return self.first.value
    
    def is_empty(self):
        return self.first == None
    
# s = LinkedListQueue()
# s.enqueue(4)
# s.enqueue(2)
# s.enqueue(3)
# print(s.dequeue())
# print(s.dequeue())
# print(s.peek())
# print(s.is_empty())
# print(s.dequeue())
# print(s.is_empty())
# print(s.dequeue())