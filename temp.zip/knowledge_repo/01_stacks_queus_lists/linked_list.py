import re


class LinkedList:
    class Node:
        def __init__(self, value, next) -> None:
            self.value = value
            self.next = next
    
    def __init__(self) -> None:
        self.head = None
        self.size = 0
    
    def size(self):
        return self.size
    
    def push(self, item): # O(1) - add to start of list
        self.head = self.Node(item, self.head)
        self.size += 1
    
    def pop(self): # O(1) - remove from start of list
        if self.head is None:
            raise Exception("List is empty")
        removed = self.head
        self.head = removed.next
        self.size -= 1
        return removed.value

    def insert(self, item, index): # O(n)
        i, cur, prev = 0, self.head, None

        while i<self.size:
            if i == index:
                new = self.Node(item, cur)
                self.size += 1
                if i == 0:
                    self.head = new
                else:
                    prev.next = new
                break   
            i, cur, prev = i+1, cur.next, cur

        if cur == None: # Edge case: when index > list size then by the end we reach the back of list which points to null
            prev.next = self.Node(item, None)
            self.size += 1

    def remove(self, index): # O(n)
        i, cur, prev = 0, self.head, None

        while i<self.size:
            if i == index:
                removed = cur
                prev.next = removed.next
                self.size -= 1
                return removed.value
            i, cur, prev = i+1, cur.next, cur
   
    def __str__(self):
        x = []
        cur = self.head
        while cur is not None:
            x.append(cur.value)
            cur = cur.next
        return str(list((x)))

llist = LinkedList()
llist.push(1)
print(llist)
llist.push(2)
print(llist)
print(llist.pop())
print(llist)
llist.push(3)
print(llist)
llist.push(4)
print(llist)

llist.insert(0, 0)
print(llist)

llist.insert(77, 2)
print(llist)

llist.insert(333, 333)
print(llist)

print(llist.remove(2))
