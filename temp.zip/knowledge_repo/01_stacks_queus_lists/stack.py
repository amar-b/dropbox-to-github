"""Stack usuing standard library 'list' (implemented as dynamically growing arrays)
    O(1) push/pop
"""
class Stack:
    def __init__(self):
        self.stack = []
    
    def push(self, item):
        self.stack.append(item) #add
    
    def pop(self):
        if self.is_empty():
            raise Exception("cannot pop: Stack is empty")

        return self.stack.pop(); #remove

    def peek(self):
        if self.is_empty():
            raise Exception("cannot peek: Stack is empty")

        return self.stack[len(self.stack)-1] #peek

    def is_empty(self):
        return len(self.stack) == 0 #empty

"""Stack implemented using linked list"""
class LinkedListStack:
    class StackNode:
        def __init__(self, item, nextNode):
            self.value = item
            self.next = nextNode
        
    def __init__(self):
        self.top = None #top = top of stack 

    def push(self, item):
        self.top = self.StackNode(item, self.top)
    
    def pop(self):
        if self.is_empty():
            raise Exception("cannot pop: Stack is empty")

        removed_node = self.top
        self.top = removed_node.next
        return removed_node.value
    
    def peek(self):
        if self.is_empty():
            raise Exception("cannot peek: Stack is empty")

        return self.top.value

    def is_empty(self):
        return self.top == None

# s = LinkedListStack()
# s.push(4)
# s.push(2)
# s.push(3)
# print(s)
# print(s.pop())
# print(s.pop())
# print(s.peek())
# print(s.is_empty())
# print(s.pop())
# print(s.is_empty())
# print(s.pop())