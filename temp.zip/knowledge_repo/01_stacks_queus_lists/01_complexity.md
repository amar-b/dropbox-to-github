# Stack
- push O(1)
- pop O(1)
- peek O(1)
- isEmpty O(1)

# Queue
- push O(1)
- pop O(1)
- peek O(1)
- isEmpty O(1)
