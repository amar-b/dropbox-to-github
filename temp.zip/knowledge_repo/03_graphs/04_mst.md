# MST
- if all the edges have the same weight the minimum number of edges need to connect a connected graph is (n-1) where n is the nubmer of nodes
    + Ie every spanning tree of an unweighted graph is minimal

- Prim vs Kruskal
    + use kruskal when graph is sparse