https://stackabuse.com/courses/graphs-in-python-theory-and-implementation/lessons/dijkstras-algorithm/
# Dijkstras
- find shortest distance between node and every other node
- Greedy algorrim that uses priority queue to greedily get the successors
- At each iteration (while queue)
- [implementation](./dijkstra.py)

## Complexity
- Same as DFS/BFS except that each priority q get/put operations takes O(log V) where V is the nodes in the pq
- $O(V log V))$ to get all items in the pq
- $O(E log V))$ to explore neibours and add them to pq
- total: $O( (V+E) log V )$ which reduces to $O(E Log V)$ since $E \geq V-1$


# [Uniform cost search](https://stackoverflow.com/questions/12806452/whats-the-difference-between-uniform-cost-search-and-dijkstras-algorithm)
- Uniform cost search is dijkstras but termintes when a goal state is reached
- same algorithm but not focused on finding the shortest path to a goal state
- Unfirm cost seach is uded in state space search
- Like dfs you "visit" each node before adding its children
