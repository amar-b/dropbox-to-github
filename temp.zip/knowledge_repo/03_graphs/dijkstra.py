import heapq
import math
from graph import Graph

def dijkstra(graph, source):
  distances = {n: math.inf for n in graph.nodes()}
  distances[source] = 0

  pq = [(0, source)]
  explored_list = set()
  while len(pq) > 0:
    cost, node = heapq.heappop(pq)
    explored_list.add(node)
    for child, wgt in graph.neighbors(node):
      if child not in explored_list:
        d = cost + wgt
        if d < distances[child]:
          distances[child] = d
          heapq.heappush(pq, (d, child))
  return distances

if __name__ == '__main__':
  g = Graph()
  g.add_edge(0, 1, 4)
  g.add_edge(0, 6, 7)
  g.add_edge(1, 6, 11)
  g.add_edge(1, 7, 20)
  g.add_edge(1, 2, 9)
  g.add_edge(2, 3, 6)
  g.add_edge(2, 4, 2)
  g.add_edge(3, 4, 10)
  g.add_edge(3, 5, 5)
  g.add_edge(4, 5, 15)
  g.add_edge(4, 7, 1)
  g.add_edge(4, 8, 5)
  g.add_edge(5, 8, 12)
  g.add_edge(6, 7, 1)
  g.add_edge(7, 8, 3)
  D = dijkstra(g, 0)

  print(D)
  for vertex in range(len(D)):
      print("Distance from vertex 0 to vertex", vertex, "is", D[vertex])
