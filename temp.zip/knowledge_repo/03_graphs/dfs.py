from graph import Graph

def dfs(graph: Graph, start):
    visited, stack = set(), [start]
    while len(stack) > 0:
        node = stack.pop()
        visited.add(node)

        for (child, wgt) in graph.neighbors():
            if child not in visited:
                stack.append(child)
    return visited