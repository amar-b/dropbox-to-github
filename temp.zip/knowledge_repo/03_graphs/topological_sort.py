from graph import Graph
"""Doing a dfs on a directed graph will give a toplogical sort
 * Must implement dfs as below (not using stack)
"""
def topological_sort(graph, start):
    top_list = []
    dfs_rec(graph, start, ordering=top_list)
    top_list.reverse()
    return top_list

def dfs_rec(graph: Graph, node: int, visited = set(), ordering = [], d = 0):
    visited.add(node)
    for (child, _) in graph.neighbors(node):
        # No need to check if node is in frontier because we add it to explored list when we 'push' to frontier (line 7)
            # in other words if a node is in the stack its also in the explored list
        print("  "*d, node, child, ordering)
        if child not in visited:
            dfs_rec(graph, child, visited, ordering, d=d+1)
    ordering.append(node)


# """
#     [1] ---> [2]<-------<|
#         |--> [3] --v     |
#         |-------->[4]--->|
# """

# g = Graph(is_directed=True)
# g.add_edge(1,4)
# g.add_edge(1,2)
# g.add_edge(1,3)
# g.add_edge(3,4)
# g.add_edge(4,2)
# l = topological_sort(g, 1)
# print(l)

# g = Graph(is_directed=True)
# g.add_edge(1,2)
# g.add_edge(1,3)
# g.add_edge(3,4)
# g.add_edge(1,4) #moved from prev example
# g.add_edge(4,2)
# l = topological_sort(g, 1)
# print(l)

# Both example result in same sorting