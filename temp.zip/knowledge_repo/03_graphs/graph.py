"""Graph represented as a dictionary mapping a key to a list where each key is a node and each set are its neighbors
"""
class Graph:
  def __init__(self, is_directed=False):
    self.g = dict()
    self.is_directed = is_directed

  def add_edge(self, n1, n2, w=1):
    if n1 in self.g:
      self.g[n1].add((n2, w))
    else:
      self.g[n1] = {(n2, w)}

    if self.is_directed:
      return

    if n2 in self.g:
      self.g[n2].add((n1, w))
    else:
      self.g[n2] = {(n1, w)}

  def add_node(self, n):
    self.g[n] = set()
    
  def nodes(self):
    return list(self.g.keys())

  def neighbors(self, n): #returns neibour and edge weight
    if n in self.g:
      return self.g[n]
    return set()

if __name__ == '__main__':
  g = Graph()
  g.add_node(1)
  g.add_edge(1,2)
  g.add_edge(2,3)
  g.add_edge(4,1)
  g.add_node(5)
  print(g.neighbors(1))
  print(g.neighbors(2))
  print(g.neighbors(3))
  print(g.neighbors(4))
  print(g.neighbors(5))