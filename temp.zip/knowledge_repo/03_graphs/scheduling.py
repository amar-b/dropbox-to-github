
""".git/

There are a total of numCourses courses you have to take, labeled from 0 to numCourses - 1. 
You are given an array prerequisites 
  where prerequisites[i] = [ai, bi] indicates that you must take course bi first if you want to take course ai.
  For example, the pair [0, 1], indicates that to take course 0 you have to first take course 1.
Return the ordering of courses you should take to finish all courses. 
  If there are many valid answers, return any of them. 
  If it is impossible to finish all courses, return an empty array.
"""
class Solution:
    class DGraph:
        def __init__(self, size):
            self.graph = {c: set() for c in range(size) }
            
        def add_edge(self, src, dtn):
            self.graph[src].add(dtn)
            
        def nbrs(self, node):
            return self.graph[node]
        
        def nodes(self):
            return list(self.graph.keys())
        
    class Status: # used to determine if graph is a DAG
        is_valid = True
        
    def topological_sort(self, graph, node, status, visiting, explored, top_list):
        if status.is_valid == False:    #stop recursing if state is invalid
            return 

        visiting.add(node)  #visiting node
        
        for child in graph.nbrs(node):
            if child in visiting:
                status.is_valid = False #we shouldn't encounter a node we're still in the middle of visiting (otherwise cycle)
                return
            elif child not in explored:
                print('c', child)
                self.topological_sort(graph, child, status, visiting, explored, top_list)

        visiting.remove(node)  #done visiting
        explored.add(node)     #explored
        top_list.append(node)  #add to list

            
    def get_ordering(self, graph, start, status): 
        visiting = set() #visiting but havent explord children
        explored = set() #explored children (done visiting)
        top_list = []
        self.topological_sort(graph, start, status, visiting, explored, top_list)
        
        return top_list, explored
        
    
    def remove_dups(self, rev_ord): 
        # See NOTE 2 about removeing duplicates
        s = []
        seen = set()
        for x in rev_ord:
            if x not in seen:
                seen.add(x)
                s.append(x)
        return s
                
    def findOrder(self, numCourses: int, prerequisites: List[List[int]]) -> List[int]:
        if numCourses == 1:
            return [0]
        
        #build graph
        graph = Solution.DGraph(numCourses)
        for dtn, src in prerequisites:
            graph.add_edge(src, dtn)
        
        status = Solution.Status()
        
        ordering =  []
        explored = set()
        
        for n in graph.nodes():  #see:  NOTE 1 about ordering         
            if n not in explored:        
                order, subgraph_nodes =  self.get_ordering(graph, n, status)
                
                if status.is_valid == False: #return empty list if its a DAG
                    return [] 
                
                explored = explored.union(subgraph_nodes)
                ordering.extend(order)
                
        return list(reversed(self.remove_dups(ordering)))
        

""" NOTE 1:
    Doesn't matter what order we explre the nodes. Just add all nodes visited to explore list to speed things up
    if we have 1->2 and we explore 2 before 1
        * exploring 2 will result in [2]
        * exploring 1 will result in [2,1]
        * the total concat list is [2] + [2,1]
        * after removing dups its [2,1]
    if we explore 1 first 
        * Exploring 1 will result in [2,1]. 
        * We wont need to explore 2 since 2 will be in the explore list after exploring 1
        * Thus the list is also [2,1]
    Hence ordre of exploring nodes doesn't mater
"""
""" NOTE 2:
    #if we have edges 1->3 and 2->3 then two sorts will [3,1] and [3,2]
    so the list [3,1,3,2] has duplicates
    if we remove the first '3' its invalid since 3 should be before 1
    if we remove the second '3' we have a valid list since 3 is still before 2
    in other words always remove the 2nd+ duplicates
"""