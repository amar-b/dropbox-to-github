# Adjacency list
- Hashmap/array of linked lists
- Each array index or map key represents a node
- Each array/map value is a list representing neighbors
- Will always V nodes and E edges
  + Space needed is thus O(V+E)
  + Traversal algorithms like Bfs and dfs also take O(V+E)

# Adjacency matrix
- Matrix of 1s and 0s
- A value at M_ij=1 means that node i is connected to node j
- A value at M_ij=0 means that node i is not connected to node j

# List vs matrix
## Density
- List: is good when graph is sparse
- Matrix: is good when graph is dense

## Lookup if there is an edge between i and j
- List: Traverse list of node i and/or node j -> O(E)
- Matrix: Index at M_ij -> O(1)

## neighbors
- List: Return the list of node i -> O(1)
- Matrix: search entire row of a matrix -> O(V)

## Adding node i
- List: Just add an item to map/array -> O(1) 
  + If array needs resizing thing its O(V) or O(1) amortized time.
- Matrix: Needs to resize every row -> O(V^2)

## Remove node i
- Need to search and remove every node and every edge -> O(V+E)
- Matrix: Need to resize every row -> O(V^2)

## Adding edge between i and j
+ List: Just add an item to the list connected to node i and node j -> O(1)
+ Matrix: Update the value at M_ij to be 1 -> O(1)

## Remove edge between i and j
+ List: Need to search and remove every edge -> O(E)
+ Matrix: Update the value at M_ij to be 0 -> O(1)
