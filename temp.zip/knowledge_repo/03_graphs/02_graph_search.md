#  Searching/
```Python
def search(start_node, end_node=None):
    explored_list = []
    frontier = Frontier() #frontier can be a stack, queue or pq

    frontier.put(start_node)
    while not frontier.empty():
        node = frontier.get() #next item in stack/queue/pq

        # if the objective is search then this block is needed
        # if objective is traversal, for example to find shortest path
        if end_node is not None and node == end_node:
            return "found"

        for child_node in successors(node):
            if child_node not in explored_list and frontier.contains(node) == False:
                frontier.put(child_state)

        explored_list.add(node)
        
    return "done"
``` 
# BFS
- Accomplished when the frontier is a FIFO queue
- Discovers all nodes and depth d before discovering nodes at depth d+1
- We can use bfs to find shortest path distances for unweighted graphs:
    + For any `node` that is reachable form `start_node` the path between those nodes corresponds to a "shortest patH"
    + Ie it is the path with least number of edges
    + for wighted graphs must use dijkstras
- $O(E+V)$ for adjacency list 
    - Why? Because after the algorithm terminates we are "visiting" each node once O(N) and getting the adjacency vertices of each node once O(E) 
- O(V^2) for adjacency matrix

- "visit" each node when its enqueued
  - avoid cycles because we visit siblings(x) before descendants(x)
    - since x is visited before siblings, the siblings can add x again to queue
  - if we don't 

## DFS and topological sort
- Accomplished when frontier is stack.
- Can also be solved recursively
- If a recursive implementation is used we can find topological ordering of a DAG (where sour)
- $O(E+V)$

- "visit" each each node when its popped from stack, ie before adding its children
  - avoid cycles becaus we all the descendants(x) before sibling(x)
    - and since x is visited before its descendants, the descendants can't add x again to stack
  - if we don't mark x as visited before adding the children, then descendants can add x to the stack
