"""Binary search assumes that you have a sorted array"""
def binary_search(sorted_array, key, l, r):
    if l > r:
        return -1
    mid = l + (r-l)//2
    value = sorted_array[mid]
    if key == value:
        return mid
    elif key < value: #left side
        return binary_search(sorted_array, key, l, mid-1)
    else: #right side
        return binary_search(sorted_array, key, mid+1, r)


print(binary_search([0,1,2,3], 3))