"""Binary search assumes that you have a sorted array
If there are duplicates return the left most value
"""
def binary_search_ld(sorted_array, key, l, r):
    if l > r:
        return -1
    mid = l + (r-l)//2
    value = sorted_array[mid]
    if key == value:
        if l == r:
            return mid
        return binary_search_ld(sorted_array, key, l, mid) #if we want to find right most dup use: binary_search_ld(sorted_array, key, mid, r)
    elif key < value: #left side
        return binary_search_ld(sorted_array, key, l, mid-1)
    else: #right side
        return binary_search_ld(sorted_array, key, mid+1, r)

d = [0,1,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3]
print(binary_search_ld(d, 2,0, len(d)))