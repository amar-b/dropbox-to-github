def binary_search_iter(arr, key):
  """Iterative binary search"""
  l = 0
  r = len(arr)-1
  
  while l <= r:
    mid = l + (r-l)//2
    if arr[mid] == key:
      return mid
    elif key > arr[mid]:
      l = mid+1
    else:
      r = mid-1
  return -1
  

if __name__ == '__main__':
  arr = [0,1,2,3,5,6]
  print(binary_search_iter(arr, 5))