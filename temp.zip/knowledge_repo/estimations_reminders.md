# Converstion table
## Large numbers
- Thousand - $10^3$
- Million - $10^6$
  - ex: 500M = $500 \times 10^6 = 5 \times 10^8$
- Billion - $10^9$
- Trillion - $10^12$

## Bytes
- 8 bits = 1 byte (similarly, 8 kilobits = 1 kb)
- 1024 bytes = 1 kb
- 1024 kb = 1 mb = 1024^2 bytes
- 1024 mb = 1 gb =  1024^3 bytes

## Times
- 60 sec = 1 min
- 3600 sec = 60 min = 1 hour
- 24 hours = 1 day
- 365 days = 1 year
  
# Estimating
- Convert things/timeframe to things/sec since seconds is a standard unit for lot of computer shit.
- Steps
  1. Estimate traffic
      + Reads - items read/s (ex tinyurl redirects/sec or twitter timeline views)
      + Writes - items written/s (ex tinyurl creations/sec or tweets/sec)
  2. Estimate storage
      + items written/s * size/item * duration of storage
      + size can be kb mb or gb etc
      + For cache storage assume that duration of storage could be 1 day
  3. Bandwidth (size of traffic)
      + incoming bandwidth = items written/s * size/item
      + outgoing bandwidth = items read/s * size/item
      + size can be kb mb or gb etc

# db data size
- int - 4 Bytes
- datetime - 4 bytes
- guid - 36 bytes
- varchar =  2 byte per character

------

Component design
- Size writes are slow and we need alot more reads than rights its better to keep those services sepearte