1) careers site. https://careers.google.com/how-we-hire/interview/#_
  + do practice problems found here
2) Checkout youtube channel https://www.youtube.com/playlist?list=PL590L5WQmH8cGD7hVGK_YvAUWdXKfGLJ1

Additional Prep Resources:

   https://www.youtube.com/watch?time_continue=28&v=ko-KkSmp-Lk

   https://www.youtube.com/watch?v=XKu_SEDAykw

    http://www.topcoder.com

    http://projecteuler.net

   https://careers.google.com/how-we-hire/

 

Interview Practice Materials:

    https://www.hackerrank.com/

    http://oj.leetcode.com/

    http://www.programming-challenges.com/pg.php?page=index

    www.careercup.com

    www.geeksforgeeks.org

 
 