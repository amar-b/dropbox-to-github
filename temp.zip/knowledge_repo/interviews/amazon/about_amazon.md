# History
- Launched in 1995
- "Day 1"  mission  - "to be most customer centric company"
    + Obsess over customers
    + every actin is with customer in mind
- amazon is built on the concept of a virtuous cycle focused on the customer
    ![cycle](./cycle.png)
    [vid](https://www.amazon.jobs/en/landing_pages/about-amazon)
    + Better customer experience drives traffic which attracts sellers. More sellers create a bigger selection which betters customer experience and the cycle continues.
    + Growth used to lower cost structure in inorder to lower prices. This also results in better customer experience and the cycle above continues

# Devices and services
- Amazon marketplace
- aws
- kindle, amazon fire, echo/alexa
- Amazon marketplace

