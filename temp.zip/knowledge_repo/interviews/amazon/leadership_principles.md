# Leadership principles
- Use those principles everyday to discuss ideas for new projects or decide the best approach to problem solving.
- https://interviewgenie.com/blog-1/2018/1/10/ownership

------------------------
## 1 - Customer obsession
- Start with customer and work backwards. Obsess over customer

### Example where you made a decision with customer in mind
  - Example when implementing MFA for our clients log in. One of the things we needed to enable our automation tests to not have mfa since those are test accounts without phone numbers. Initially my team through it was a good idea to use split io to create a feature flag service such that if its a test account then mfa is disabled upon log in. Otherwise the mfa workflow with that is triggered. One thing to keep in mind is that there are a handful of automation accounts. Like 3. I argued that it is better to hardcode the ids of those accounts in the mfa instead of calling the feature flag service. One reason is that the call the the split io has a latency which slows down the log in process. The other and perhaps most important is if we go this route we will be coupling our login with this third party dependency. If it goes down the log in process will be compromised. Obviously hardcoding values has the inherit issue of maintenance requiring code changes. I had the customer in mind in saying that since that additional call will slow down the login all for 3 tests accounts. The team agreed and thats what we went with.

------------------------
## 2 - Ownership
- Leaders are owners. Don't sacrifice long term value for short-term results. They never say "That's not my job"
  - Basically get the job done and ignore boundaries between departments

### Example of Time when you took personal ownership
- One of the first things I worded on at my current employee is update to this legacy account management tool. Setting it up locally was a headache because there was no documentation and no one in the team even know where to begin. Since I took ownership on this task I reached out to many people across the organization to determine how to set it up and get the access needed to get it running normally. With some hacks I was able to get it working 
- The idea was to make changes to this tool so that it facilitates the transition for moving our authentication provider. 
- Even though the change was temporary change and the tools was deprecated months later, i took ownership and make it work well.  Furthermore since very few people in the organization could even get it to work locally i understood the position as being the subject matter expert until deprecation

### Thinking about a time you went above and beyond
- Honestly I always do my best in everything i do at work. I'm always one of the highest performers wherever i go so I don't ever feel the need to go above my already high bar
- I guess example whre I would say I went above and beyond in after my work hours, one of my peers called me asking for help in debugging an issue they are seeing in prod. It wasn't something related to anything I worked on or owned. I just went above and beyond to help with that anyway.


------------------------
## 3 - Invent and simplify
- Expect and require innovation and inviting from their teams and find ways to simplify. Always looking to innovate

### time you had a creative solution to a problems

------------------------
## 4 - Learn and be curious
- Always seek to learn and grow and curious about possibilities

### Example
- Always ask mysekf how other systems work. Always looking at different repositories i don't own to see how they work and try to understand why certain decisins were made

------------------------
## 5 Hire and develop the best
- Develop other leaders and take seriously their role coaching others

------------------------
## 6 - Insist on hight standards
- Have high standards. Raise the bar and driving their teams to deliver quality products, services and processes. Ensure that defects don't get sent down the line

### Ensuring code quality
- I have high standards when it comes to code i own or my team owns. WHenever I look at a code review, I never cut any corners and will work to make sure I understand the code why its written that way. From there i can analyse the logic and find any issues with the logic or ways to simplify the code or make it more efficent or make it cleaner and easier to read. An example suggestion would be to break down a big function into smaller components or renaming a function name so its clear what its doing. On the same token I always look for more eyes on my pr because Im not perfect either and there might bes oemthing in my code that could be improved on.

------------------------
## 7 - Think big
- Create and communicate a bold direction that inspires results.

### Example of thinking big
- tech debt and thinking of scalability

------------------------
## 8 - Bias for action
- Many decisions and actions are reversible. Value calculated risk taking

-----------------------

## Success and scale bring broad responsibly
- Do better evert day, leave things better than how you found them

### Example of imporving something
- Every time i make a code change I try to also analyze the surrounding code or related code. I do that to see if there is something i can clean up or make better. So just leave the code base in a better state that it ws when i touched it. For example this could be writing better unit tests, breaking up a bif function or getting rid of a duplication.

### Example of failure





-----------------------

- Tell me about a time when you were faced with a problem that had a number of possible solutions. What was the problem and how did you determine the course of action? What was the outcome of that choice?

- When did you take a risk, make a mistake, or fail? How did you respond, and how did you grow from that experience?

- Describe a time you took the lead on a project.

- What did you do when you needed to motivate a group of individuals or promote collaboration on a particular project?

- How have you leveraged data to develop a strategy?
