Software Development Engineer, Selling Partner Recruitment and Development, New Seller Success
4-5 minutes
DESCRIPTION

Job summary
We’re looking for a Software Development Engineer to join us on our mission to recruit all the sellers in the world to start selling on Amazon, while empowering them to grow their business and provide a great customer experience. Selling on Amazon is one of the fastest growing businesses at Amazon.com and empowers millions of entrepreneurs (whom we refer to as selling partners) WW. To drive this unprecedented scale, our entrepreneurial team of sales reps, account managers, product managers, data scientists, and software engineers continuously invent new ways to scale and raise the bar for our selling partners through automation.

Key job responsibilities
As a software development engineer on this team, you will play a pivotal role in shaping the definition, vision, design, road map and development of product features from beginning to end. You will:

    Work with the team to help solve business problems.

    Design, implement, test, deploy and maintain innovative software solutions to transform service performance, durability, cost, and security.

    Use software engineering best practices to ensure a high standard of quality for all of the team deliverables.

    Write high quality distributed system software.

    Work in an agile, startup-like development environment, where you are always working on the most important stuff.

BASIC QUALIFICATIONS

    1+ years of experience contributing to the system design or architecture (architecture, design patterns, reliability and scaling) of new and current systems.

    2+ years of non-internship professional software development experience
    Programming experience with at least one software programming language.


    Bachelor's degree or foreign equivalent in Computer Science, Engineering, Mathematics, or a related field;

    3+ years of experience in the job offered or as a Software Engineer, Software Developer, or a related occupation;

    At least 1 years of experience in the job offered or a related occupation must involve: designing and developing large-scale, distributed software applications, tools, systems and services using Java, C#.net, Scala, Go, and Object Oriented Design.

    Solid understanding of Object-Oriented design and concepts

    Computer Science fundamentals in data structures

    Excellent skills in algorithm design, problem solving, and complexity analysis

    Desired to have an experience with event driven architectures / NO-SQL databases

PREFERRED QUALIFICATIONS

    Full stack

    3+ years of professional experience as a software engineer or related role.

    Experience developing complex software systems that have successfully been delivered to customers.

    Experience in communicating with users, other technical teams and senior management to collect requirements, describe software product features, technical designs and product strategy.

    Knowledge of professional software engineering practices & best practices for full software development life cycle, including coding standards, code reviews, source control management, continuous deployments, testing and operations.

    Demonstrated ability to mentor junior software engineers in all aspects of their engineering skill-sets.

    Work well in teams and respect and welcome ideas from partners, business stakeholders, and technical experts

    Passion for solving complex and interesting problems

    Passion for writing great, simple, clean, efficient code

    Maniacal Customer Obsession

Amazon is committed to a diverse and inclusive workplace. Amazon is an equal opportunity employer and does not discriminate on the basis of race, national origin, gender, gender identity, sexual orientation, protected veteran status, disability, age, or other legally protected status. For individuals with disabilities who would like to request an accommodation, please visit https://www.amazon.jobs/en/disability/us.
