## Questions to interviewer
<!-- - Could you describe in more detail what the role will be like. 
- How would my workflow look like.
- Can you describe the team that I would work with.
- Can you tell me more about the technology and dev tools tha your team uses -->
- Could you describe the management style in your organization
- What are some qualities qualities are needed to be an effective leader at google
<!-- - What do you think are qualities that make you successful in the role -->
- What is your favorite thing about working in the company
- How has the company changed since you've changed
<!-- - is there anything about my candidacy that concerns your, you would like me to clarify. -->
______________

## Introductory 
#### Tell me about yourself
- Well currently im working at rocket mortgage.
- Here I work a full stack software engineer for a bit over a year. Overall I have around 4 years of experience developing software. I've used many different technologies and programmed in many languages over the years. Last year I obtained my master's degree in computer science. During my time in school explored an array intreating topics from artificial intelligence to reasoning with uncertainly to large scale db systems.
- I won't say that Im aggressively perusing new opportunities but Im always open to new adventures.

### Why do you want to work here
- I think google is a great company because of my personal experience using google services. I think working in google along side bright team members will only help me grow and become a better engineer. I also think i would bring some new ideas and fresh perspectives to the team.

#### Why should we hire you?
- Well First of all I believe I have all the skills and qualifications to excel as an engineer in google.
- Im always on of the top performers wherever i work
- I learn fast, and I sort of have good intuition or like instincts that guide me in solving complex problems
- Beyond that i have good problem solving skills and can think creatively. I'm also passionate about tech and always looking to grow

#### Why are you leaving
- I love my role and coworkers and the company has great work life balance, but I’ve come to a point where there are no longer growth opportunities on my team. In addition I don't think that im challenge enough at my current role so Im looking for new challenges.

#### Greatest strength
- Appetite for learning
- Problem solving; 
- My ability to adapt

#### Greatest weakness
- My greatest weakness Im sometimes too detail oriented
- If there is something I don't understand my nature is deep dive into learning and see if i can understand it
- In software engineering there will always be things that you need to abstract away
- I recognize that i don't need every detail and its something i am working on

#### Most proud of:
- How i was able to be manage school and a full time job
- Even with a demanding course work and having to work overtime some days,
- I was able to get a 4.0 in all my classes so far while excelling at my full time job as well
- so im proud of that
 
#### In five years
- I as a highly skilled and knowledgeable senior engineer. 
- being a subject matter expert and owning more systems
- and mentoring and guiding junior engineers.

______________

## Preference
#### What work environment do you prefer?
- I prefer an environment where there is open communication, and honest feedback. 
- I also want to do work that is challenging. I'm a problem solver so I personally find challenging work to be stimulating

#### Who is your ideal manager
- I prefer a manager who is a little more hands of
- and doesn't feel the need to micromanage everything.
- someone who is honest and provides good feedback
- Someone who is fair and rewards talent and hard work

______________

## Misc
- What is something that you have learned recently
- blog about paginating apis. 

- Project you worked on in spare time


- How do you keep your skills current
  + Reading blogs and forums. and watching tech vids
  + Taking online courses

#### What do you want to accomplish in first 90 days
  + Be acquainted with the business domain im working on
  + Be familiar with the technology, code repos, piplines, and tools I would be using
  + madK some valuable code contributions
  + bring in some fresh ideas and fresh eyes to help innovation

______________

## Behavioral
#### Tell me about a mistake?
- In sofware engineering bugs which are really mistakes are inevitable
- I obiovusyly shoot to never have bugs in anything I write and do that with unit tests and e2e tests, but sometimes thats not enough or sometimes
- One example that I rememvber Is a was hooking making changes to a service that acts as a proxy between two services. Where we get an email, save it and then pass that email on to the third party. THe issue is that the email from the upstream service was a mix of uppercase and lowercase letters while the downstream system expects the email to be all lowercase since. I were I didn't account for this and this caused issues with password resets.

- One time I missed a deadline for a task at t my older job.
- I've realized that my time management isn't as good as a I thought. 
- So I've decided to start using a todolist app on my phone to track all that tasks I'm working on. 
- Since then I never missed a deadline.

#### Tell me about a disagreement
- There was a disagreement i had with a cowoker that originated from miscommunication
- To keep thinks professional and positive we had to discuss it and make amends
- I sat down with them one day,  and took initiaite by aplogolzing for my part in the whole mess
- From then on we worked well togther

#### Tell me about a high pressure situation
- At mu last job, one of my cowerkes have decided to leave the company
- My supervisor has assigned alot of their tasks for me to work on in addition to my current tasks
- This was clearly alot of work
- But I was able to stay calm and focused on completing all the tasks.

#### Tell me about a goal
- A few years go a set a goal to teach myself how to code. I set aside some time each day to learn something new. In a few months time I was able to write computer programs.

#### Tell me about a challenge
- Last minute defects when deploying pos
- wither its challenges related to solving complex propblems of fixing issuies in production, on dealing with a legacy system without documentation
- One example is wanting to use an another system to get some data. Since it is giong to be a endpoint used alot I need to load test it. but upon load testing it I realized that its not performant. The team owning the system had other piorities but intead of just resinging and saying Ib blocked I took on the challenge of udnerstanding the system and figuring out the bottleneck. 


### Example of Time when you took personal ownership
- One of the first things I worded on at my current employee is update to this legacy account management tool. Setting it up locally was a headache because there was no documentation and no one in the team even know where to begin. Since I took ownership on this task I reached out to many people across the organization to determine how to set it up and get the access needed to get it running normally. With some hacks I was able to get it working 
- The idea was to make changes to this tool so that it facilitates the transition for moving our authentication provider. 
- Even though the change was temporary change and the tools was deprecated months later, i took ownership and make it work well.  Furthermore since very few people in the organization could even get it to work locally i understood the position as being the subject matter expert until deprecation

### Thinking about a time you went above and beyond
- Honestly I always do my best in everything i do at work. I'm always one of the highest performers wherever i go so I don't ever feel the need to go above my already high bar
- I guess example whre I would say I went above and beyond in after my work hours, one of my peers called me asking for help in debugging an issue they are seeing in prod. It wasn't something related to anything I worked on or owned. I just went above and beyond to help with that anyway.

- Always ask mysekf how other systems work. Always looking at different repositories i don't own to see how they work and try to understand why certain decisins were made

### Ensuring code quality
- I have high standards when it comes to code i own or my team owns. WHenever I look at a code review, I never cut any corners and will work to make sure I understand the code why its written that way. From there i can analyse the logic and find any issues with the logic or ways to simplify the code or make it more efficent or make it cleaner and easier to read. An example suggestion would be to break down a big function into smaller components or renaming a function name so its clear what its doing. On the same token I always look for more eyes on my pr because Im not perfect either and there might bes oemthing in my code that could be improved on.

### Example of imporving something
- Every time i make a code change I try to also analyze the surrounding code or related code. I do that to see if there is something i can clean up or make better. So just leave the code base in a better state that it ws when i touched it. For example this could be writing better unit tests, breaking up a bif function or getting rid of a duplication.


### Example where you made a decision with customer in mind
  - Example when implementing MFA for our clients log in. One of the things we needed to enable our automation tests to not have mfa since those are test accounts without phone numbers. Initially my team through it was a good idea to use split io to create a feature flag service such that if its a test account then mfa is disabled upon log in. Otherwise the mfa workflow with that is triggered. One thing to keep in mind is that there are a handful of automation accounts. Like 3. I argued that it is better to hardcode the ids of those accounts in the mfa instead of calling the feature flag service. One reason is that the call the the split io has a latency which slows down the log in process. The other and perhaps most important is if we go this route we will be coupling our login with this third party dependency. If it goes down the log in process will be compromised. Obviously hardcoding values has the inherit issue of maintenance requiring code changes. I had the customer in mind in saying that since that additional call will slow down the login all for 3 tests accounts. The team agreed and thats what we went with.
