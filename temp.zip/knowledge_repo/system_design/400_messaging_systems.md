# Short vs long polling
- Short polling - 