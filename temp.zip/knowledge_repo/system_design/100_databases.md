# Keys
- Super key: A set of attributes/cols that uniquely identify a row/tuple
- Candidate key: A minimal candidate key
  - One candidate key is chosen as the primary key.
  - Other candidate keys are alternate keys
- Prime attribute: Attributes that make up the candidate key

# db constants
- Primary key constraint: Forbids duplicate in one more more columns
- Entity integrity: no key attribute can be null
- Referential integrity: If FK points to another refer to another relation the PK must exist there
- Check - restrictions of data to be in specific formats or ranges
- Null - values in columns cannot be null
- Other ways to enforce constants: Triggers, stored procs

------------------
# Database normalization (3NF)
- Functional dependency specifies how the value of a column depends on another column
- normalization is a way to create good schemas by decomposing the table to get a higher normal form
  + This is to avoid duplication

## 1NF
+ No repeating groups (lists inside of columns)
+ To normalize move repeating in anew relation with 
  - PK of new relation = (PK of old relation) + (some unique value of the repeating group)

## 2NF
- If some columns don't depend on entire primary key (i.e. no partial dependencies) are to be moved.
- To normlize move columns that depend on only a portion of primary key to new relation.
  - PK of new relation = (Columns on old relation's PK that the moved columns depend on)

## 3NF: 
- Columns that depend on a key attribute through non-key attribute are to be moved.
- To normalize move non-key columns that don't depend on a key attribute to a new relation
  + PK of new relation = (The non-key columns of old relation that the moved columns depend on)

## BCNF
- Very similar to 3NF in that they both remove dependencies to non key attributes 
- 3NF focuses on transitive dependency. but BCNF makes a stronger constraint
- To normalize make sure that key attribute cannot depend on a non-key attribute

## Why normalize
- Normalized data can lead to anomalies
- Anomalies lead to redundant data, require more storage and hard to maintain
- However normalization can reduce query performance since joins are required

------------------
# Serializable and concurrency control

## Transactions
- read only queries can run concurrently. However when you make updates you have to worry
- To fix this we should execute queries as transactions to ensure consistency and reliability
- Consistency
  + A db is consistent if it satisfies all integrity constraints (defined above)
  + We want concurrent transactions to result in consistent db states. This gets hard with replication
- Reliable
  + we want to be fault tolerant and recover when there are faults
- Transaction management keeps the db consistent even with concurrency and failure

## properties of transactions mgmt 
### A - atomicity
- Transaction treated as a single unit
- all actions are complete or non of them

### C - consistency 
- Consistency is a measure of correctness

### I - isolation
- Each transaction must see a consistent db state at all time. Don't see dirty data
- Isolation levels
  1. Read uncommited
  2. Read commited
  3. Reperatable read
  4. Serializable

### D - durability
- Ensures that transaction commits are permanent


## Concurrency control and serializing transactions
- Deals with isolation and consistency props of transaction management
- Executing each transaction in a serial schedule (ie. sequentially) guarantees total isolation and consistency
- A serializable schedule is a schedule that is equivalent to a serial schedule

- ideally we want transactions to be serializable:
  - why? because its the highest level of isolation of transactions
  - i.e. when they execute simotamously they output the same results as a serial schedule.
- 2 phase locking is a concurrency control mechanism that guarantees serializablity