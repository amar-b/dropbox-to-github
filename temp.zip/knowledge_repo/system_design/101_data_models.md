# Types of data models

## NoSql
- Easier to scale horizontally
- schema flexibity
- Better performance due to locality
- Closer to data strucures modelled by application
- Can model one-to-one and and one-to-many, but cant model many to one or many to many typically
+ Usually can't do joins but can emulated using application code
+ cant refer to nested items directly (need something like an xpath)

## Relations
- Tried and tested
- Relational database good when relations between entities are complex
- Good when data is inheritiyly relational that is different entities relate to one another
- Good when object used by application is not represented as document
- Good when you want to enforce "static typing" and database integrity
- Suport for joins
+ Works well with for many to one and and descent for many-to-many

## Graph databases
+ Good for when relationships between entities are complex and network like


# Cap theorem
- Can only choose between consistency and availability since network partitions are inevitable
