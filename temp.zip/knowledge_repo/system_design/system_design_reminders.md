# Distributed system
- A distributed system is a system where which components are spread across different nodes on a network.

# Redundancy and Replication
- Redundancy is having more than on node or component of a system to improve reliability and potentially improve performance. Two types
    + Active: All nodes are live and traffic flows to all nodes
    + Passive: Some nodes are not live and are serve as a backup
- Replication: Sharing information in order to ensure consistency between redundant components

# Partitioning/Sharding
- Types of partitions
    + Vertical - split but columns
    + Horizontal (ie sharding ) - Split by rows
- Benefits
    - Scalability - There is an upper limit to vertical scaling
    - reliability
    - Improve performance
        - Improve query performance since there is less rows/cols to scan
        - Allows for parallelization
        - Locality of access. Position data close to where its accessed
- Issues:
    + Joins may not be feasible. De-normalization has its issues 
    + Referential integrity
        + Can have FK relationships if the referenced is in another server



