# Tiers
- A tier is a separation of components in an application or service
- A component can be:
  - dbs
  - backend server
  - ui
  - messaging
  - caching 

### Single Tier
- UI, backend logic and db in same machine
- example MS office, adobe Photoshop
- Upsides: No network latency, security, privacy
- Downsides: Publishers have no control over application, performance depends on machine

### Two Tier
- UI and business logic in one machine, backend db server in another
- example: mobile games, todo list app
- Upsides: Us low network latency. Publishers can control data (unlike single tier)
  
### Three Tier - "client server"
- UI, backend (business logic) and db all in different machines
- Upsides: Publishers have control over both data and business logic
### N-tier
- more than 3 compos in system
- ex cache, lb, message queues, search servers, etc
- aka microservice architecture/distributed systems
- Pros:
  + Loosely coupled responsibilities that don't interfere one another (db layer should't have business logic --stored proc :bad)
  

# Web architecture
- web architecture consists of many components, like UI, db, message, ques, cache.

## Web/http servers
- Is a computer that can serve requests via http
- Servers running web applications are called app servers,
- There are different kinds of servers like db servers, proxy servers, mail servers, file servers, etc
  
## Http protocol and Rest
- Http is protocol for communication exchange in the www
- Rest api is a http api that adheres to rest architectural constraints

## Http push/pull
### Pull
- Client sends request and server responds

## Push
- Client sends reuest to server once, and server keeps pushing new updates to client
- In regular client server communication, there is ttl for every request afterwhich browser kills the connections.
- Http ush allows for persistent connections b/w client and server
- Cons: resource intensive and servers and limit to how many socket are open
- Ways to do http push
    - Long polling: wait until server responds and then send anohter request
    - Web sockets- Uses tcp to provide bi-direction comm
    - Server sent events: Push events from server to client
    - Streaming over http: break down data into chunks. Used for media content