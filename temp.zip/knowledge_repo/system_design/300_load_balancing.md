# Load balancing (LB)
- load balancers distribute traffic across servers running in a cluster
- Allows for scaling and high availability when traffic increases
- If server goes down, lb will re-route traffic to an active server
- Used manage load of application servers, db servers, queues, etc
- To route traffic to active nodes, load balancer must use health checks

- Three ways to do lb
  1. Dns lb
  2. hardware lb
  3. software lb

-------------
## DNS LB
### What is dns (move to another file??)
- Every computer in the web has an ip adddress. Ips are used to find the machines you are sending requests/data to.
- but we need a human readable name.
 Dns systems map a domain name, ex amazon.com ti ab uo
- Dns system consists of
  1. Dns recursive nameservers aka dns resolver
  2. Root nameservers
  3. Top-level domain nameserver
  4. Authoritative nameserver
- Flow
  1. When you type amazon.com the browser sends a requests to dns resolver
  2. Resolver forwards request to root nameserver.
  3. Root nameserver returns the addr of the top-level domain server based on the top level domain. Top level domain for amazon.com is ".com"
  4. Resolver sends a request to the top-level domain server 
  5. The top-level domain server returns the address of the Authoritative server
  6. Authoritative returns the ip amazon.com
  7. Resolver caches the ip and forwards it back top browser

### Dns load balancing
- A service like amazon has many ips obviously
- The authoritative serer can return a permutation for list of ips
- The first item in the permutation is the next item in the round robin
- We return list in case the server of the first ip is down
- Limitations:
  + dns resolver caches the ips so that means it can cache out of service ips
  + No way to account for which server has more load with round robin

-------------
## Hardware lb
- hardware lb sit in front of app severs and distribute load
- Fast performance but need to manage the hardware infrastructure

## Software lb
- ex: HaProxy
- Cost effective and offers more flexibility to devs.
- Less performant than hardware lb

## LB algorithms
- Round robin - Keep a pointer to a last used ip to find the next ip to return
- Weighted round robin - Add weights to ips based on traffic. Return ips based on wight 
- Random - select a random ip
- Least connections - Route to ip with least connections. 
  + Good for long opened confections like gaming
- Hash - Hash the source ip. This guarantees the same source ip routed to same ip. 
  + Good for caching: Reduces cache replication and cache misses