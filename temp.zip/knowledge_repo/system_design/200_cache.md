# Caching
- Put shit in memory to help have low latency and high throughput
- Can be used at different layer of an application from browser to the db layer

- Dynamic data: 
  - data that changes too often
  - Need to worry about keeping cache up to date and not running out of space
- Static data: 
  - data that doesn't change
  - ex images, css, etc
  - Can be cached on browser, CDN or server

## Cache updates: 
### Cache aside / Cache invalidation
- Check if in cache. If hit return data. if not go to db and update cache
- Cached content has a ttl afterwhich the cache is invalidated
- Good for read heavy workflows were data isn't updated alot

### Write through cache
- Always update cache when data changes. 
- Always consistent but slower
- Used when consistency is desired. But is not the best performant

### Write back cache
- Cache is updated. Then cache is used to update db later
- Good for write intensive apps since it prevents to many db writes. Risks losing data

## Cache eviction: 
- Handling cases when cache is full
- Types
  - lru - remove least recently used
  - lfu - remove least frequently used
  - random replacement