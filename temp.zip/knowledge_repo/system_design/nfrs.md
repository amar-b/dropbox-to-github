# Types of goals
- scalable/elastic
- available/reliable
- Secure
- High volume
- low latency

# Design paths
- Read vs write heavy?
- IF heavily unbalanced might want to have separate backend servers for each operation
- Read heavy may with alot of throuput benefit from alot of caching for ex
  