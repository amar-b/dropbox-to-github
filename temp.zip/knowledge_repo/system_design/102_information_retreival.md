# db Indexing
- When we create an index to we make retrieval fast
- in rdbms indexing slows down writes since we need to update both table and its indexes


- Families of storage engines
1. Log structured engines - Hash indexes and LSTree

## Log strucuted enginess
- Use an append only log of key and value paris
- Appends are fast but reads require indexes for fast retrieval
- Hash index
    + in memeory index where each key points to an offset in log file
    - to aovid running out of disk space we can use multiple segments and merge segments to reduce their size
    + Good for situations whre value of each key gets updated alot but there arn't that many keys

2. Page oriented engines - B-trees
