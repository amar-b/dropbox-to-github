"""Finds a subarray with the largest sum (not necessarily the largest subarray with that sum)
   Local_max(i) = max( arr[i], arr[i]+Local_max(i-1) )
* think of local max as a function goes up and down. Global max is the peak of the plot.
* choosing arr[i] implies that Local_max(i-1) is negative. 
    + Every time we set Local_max(i) = arr[i] that means the local max subsequence starts at i. 
    + Intuitively this makes sense since that happens when Local_max(i-1) is negative.
* If Local max is greater than current global max then we update the global max to be the local max
"""
def max_subarray(arr):
  local_max, global_max = arr[0], arr[0]

  for i in range(1, len(arr)):
    local_max = max(arr[i], arr[i]+local_max)
    global_max = max(global_max, local_max)

  return global_max

def max_subarray_stn(arr):
  local_max, global_max = arr[0], arr[0]
  local_range, global_range = (0, 0), (0, 0) # each range contains the (start, end) of the subarray

  for i in range(1, len(arr)):
    local_max = max(arr[i], arr[i]+local_max)
    local_range =  (local_range[0], i)
     
    if local_max == arr[i]:
      local_range = (i, i)  #reset local range since prev/left local_max is negative
    
    if local_max > global_max:
      global_max = local_max
      global_range = (local_range[0], local_range[1])

  s, e = global_range[0], global_range[1]
  return global_max, arr[s: e+1]

if __name__ == '__main__':
  arr = [-2, 10, 100, 10, -600]
  print(max_subarray_stn(arr))
  
  arr = [-2, 10, 100, 10, -600, 1, 599]
  print(max_subarray_stn(arr)) #:)
      
  


  
