class Solution:
    def maxProduct(self, nums: List[int]) -> int:
        """
            if we have all pos numbers then 
                max(i) = v(i)*max(i-1)
                where max(i) is maxmum subarray to left of i
            
            if we have pos number and zeros then 
                max(i) = v(i)*max(i-1)  if v(i-1) !=0
                max(i) = v(i)           if v(i-1) = 0
                where max(i) is 0 or the maxmum subarray since the last zero
            
            if we have a mix of pos, zero and neg numbers
                we keep track of both max(i) and min(i) and swap them when a neg number is encountered
                intuituion is that a -ve number will make the max value the min and the min value the max
                    + if min is -ve and max is +ve then min becomes +ve and max becomes -ve
                    + if min and max are both +ve then both become -ve but max < min
                    + if min and max are both -ve then both become  +ve but min > max    
        """
        max_prod, min_prod = nums[0], nums[0]        
        max_value = nums[0]
        
        for i in range(1, len(nums)):
            num = nums[i]
            if num < 0:
                max_prod, min_prod = min_prod, max_prod              
            max_prod = max(num, num*max_prod)
            min_prod = min(num, num*min_prod)
            max_value = max(max_prod, max_value)
        
        return max_value
