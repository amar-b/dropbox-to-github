"""Given a string s, return the longest palindromic substring in s
  sliding window pattern + dp
  if ss indexes is in range(i,j) then ss is a palindrome when
    if len(ss) = 1 
    if len(ss) = (2 or 3) and s[i] == s[j]
    if len(ss) > 3 and s[i] == s[j] and subsring in range(i+1, j-1) is a polidrome
"""
def longestPalindrome(self, s: str) -> str:
  cache = set() # start and end index inclusive
  n = len(s)
  longest_size, longest = -1, ""

  for size in range(1, n+1): #start is start index of substring
      start = 0     
      while start+size <= n:
          end = start+size-1
          ss = s[start:end+1] # get substring of of size size
          is_pol = False
          if len(ss) == 1:
              is_pol = True
          elif (len(ss) == 2 or len(ss) == 3) and s[start] == s[end]:
              is_pol = True
          elif (s[start] == s[end]) and ((start+1, end-1) in cache):
              is_pol = True
          if is_pol:
              cache.add((start,end))
              if len(ss) > longest_size:
                longest_size, longest = len(ss), ss
          start += 1
  return longest