"""Given an array of integers with size n, find the maximum revenue obtained by by cutting the rod into 2 or more pieces.
  + Each cost[i] is the cost to cut a rot of size i+1
  + If cost[n-1] for an array of size n is large then optimal solution is no cuts
  ex
  len_i:   1, 2, 3, 4,  5,  6,  7,  8,  9, 10
  cost_i:  1, 5, 8, 9, 10, 17, 17, 20, 24, 30
"""

def cord_cutting(costs):
  """Dynamic programming solution
    + Opt(n) = cost[i] + Opt(n-1) where n is the length of the rod 
    O(N^2) runtime
  """
  cache = {0: 0}  # initialize cache with 0 as the cost of a rod of length 0

  for cord_len in range(1, len(costs)+1):
    max_cost = -1
    for cut in range(1, cord_len+1):
      cost = costs[cut-1] + cache[cord_len-cut]
      max_cost = max(max_cost, cost)

    cache[cord_len] = max_cost

  return cache[len(costs)]

def cord_cutting_solution(costs):
  """Returns not just the optimal value but also the solution: the cuts lengths needed to obtain that value
  """
  cache = {0: 0}  # initialize cache with 0 as the cost of a rod of length 0
  best_cuts = {0: 0}
  for cord_len in range(1, len(costs)+1):
    max_cost = -1
    for cut in range(1, cord_len+1):
      cost = costs[cut-1] + cache[cord_len-cut]
      max_cost = max(max_cost, cost)
      if max_cost == cost:
        best_cuts[cord_len] = cut # store the best cut for this length

    cache[cord_len] = max_cost

  n = len(costs)
  optimal_cuts = []
  while n>0:
    optimal_cuts.append(best_cuts[n])
    n = n - best_cuts[n]

  return cache[len(costs)], optimal_cuts

def cord_cutting_rec(costs, cord_len=None):
  """Recursive solutionL
    Expensive because each recursive step calls itself cord_len times and it solves the same subproblems repeatedly
    T(N) = sum_^{cord_len} T(N/2) + O(N): Exponential runtime
  """
  if len(costs) == 1:
    return costs[0]
  elif len(costs) == 0:
    return 0

  cord_len = len(costs) if cord_len is None else cord_len
  max_cost = -1
  for size in range(1, cord_len+1):
    cost = costs[size-1] + cord_cutting(costs, cord_len-size)
    max_cost = max(max_cost, cost)

if __name__ == '__main__':
  costs = [1, 5, 8, 9, 10, 17, 17, 20, 24, 30]
  print(costs)
  print('n', len(costs))
  print(cord_cutting(costs))

  print()
  costs = [1, 5, 8, 9, 10, 17, 17]
  print(costs)
  print('n =', len(costs))
  print(cord_cutting_solution(costs))