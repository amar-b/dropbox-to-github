"""https://leetcode.com/explore/interview/card/google/64/dynamic-programming-4/3086/
You are given an array prices where prices[i] is the price of a given stock on the ith day.

You want to maximize your profit by choosing a single day to buy one stock and choosing a different day in the future to sell that stock.

Return the maximum profit you can achieve from this transaction. If you cannot achieve any profit, return 0.
"""
class Solution(object):
    def maxProfit(self, prices):
        pv = 0, prices[0]        #highest peak since the last lowest valley
        lv = 0, prices[0]        #global lowest valley
        global_max = 0

        for i in range(1, len(prices)):
            val = prices[i]

            # if price lower than lv, then we have a new global lowest vally so far
            # update global max, decrease lv and reset pv
            if val < lv:
                global_max = max(global_max, pv-lv)
                
                lv = val
                pv = val # reset cuz peak can't be to left of valley

            # If price greater than pv, increase pv
            if val > pv:
                pv = val
            
            # lv can no longer increase at last iteration, so update global max
            if i == len(prices)-1:
                global_max = max(global_max, pv-lv)

        
        return global_max