"""find the subset of non-adjacent elements with the maximum sum
  using Dp
  m(i) = sub array at pos i

  m(0) = arr[0]
  m(1) = max(m(0), arr[1])
  m(i) = max(m(1-1), arr[i], m(i-2)+arr[i])
"""
def max_non_adj_subarray(arr):
    cache = {}
    for i in range(len(arr)):
        if i == 0:
            cache[i] = arr[0]
        elif i == 1:
            cache[i] = max(cache[i-1], arr[i])
        else:
            cache[i] = max(cache[i-1], arr[i], cache[i-2]+arr[i])
    return cache[len(arr)-1]

if __name__ == '__main__':
    arr = [2, 1, 5,8, 4]
    print(max_non_adj_subarray(arr))