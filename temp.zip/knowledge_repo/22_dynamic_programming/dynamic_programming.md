# Dynamic programming
- LIke divide and conqour solves the problem by combining solutions to subproblem
- Divide and conquer: Divide into *disjoint* sub-problems, solve them recursively and combine the results
- Dynamic prog: Applies when subproblems overlap: Subproblems share subproblem
- Used for optimization problems: many candidate solutions but we want the solution(s) with the 'best' value
- 4 steps when working with dynamic programming problems
  1. Characterize the structure of the optimal solution. "The optimal solution must be this or that"
  2. Recursively define the value of an optimal solution
  3. Compute the value of an optimal solution in a bottom up fashion
  4. Compute the optimal solution from computed info 
    + skip this if you only care about the *value* of the optimal solution
    + use this if you want the solution itself
