def regex_match(word, ptn):
  if len(ptn) == 0:
      return len(word) == 0
  
  match = word != "" and (word[0] == ptn[0] or ptn[0] == ".")
  star_nxt = len(ptn) > 1 and ptn[1] == "*"
  if star_nxt:
      return (self.isMatch(word, ptn[2:])
                  or  ( match and self.isMatch(word[1:], ptn[:]) ))
          
  else:
      return match == True and self.isMatch(word[1:], ptn[1:])
