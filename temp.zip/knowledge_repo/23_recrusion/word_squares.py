"""https://leetcode.com/explore/interview/card/google/62/recursion-4/370/
"""
class Solution(object):
    """Use recursion to build a word square from a given set of words.
      At each recusive step we fix a word and build a word square from the remaining words.
      The word we fix must be a word that creates a word square.
      The word square is one whre for i!=j s[i][j] == s[j][i]
    """
    def is_word_square(self, sq):
        size = len(sq)
        w = [i[:size] for i in sq]
        for i in range(size):
            for j in range(size):
                if i != j and w[i][j] != w[j][i]:
                    return False
        return True
    
    def build_square(self, sq, words, word_squares, max_size):
        size = len(sq)
        if size == max_size: # full square
            word_squares.append(sq)
        else:
            for word in words:
                candidate_sq = sq[:] + [word]
                if self.is_word_square(candidate_sq):
                    self.build_square(candidate_sq, words, word_squares, max_size)
        
    def wordSquares(self, words):
        if len(words) == 0:
            return []
        
        result = []
        max_size  = len(words[0]) #get size of any word 
        self.build_square([], words, result, max_size)
        return list(sorted(result))

class Solution2(object):
    """This variation exploits the fact that for word squares the row[i] will have the same value as col[j]
         since we know the whole word for words added to the square, 
            we generate col[j] from words we have in the square
                then use substring matching to see if any word/row starts with col[j]
                    if so then that word becomes the new word and recurse
                    if not then backtrack
    """
    def build_square(self, sq, words, word_squares, max_size, prefix_cache):
        size = len(sq)
        if size == max_size: # full square
            word_squares.append(sq)
        else:
            if size == 0:
                matched_words = words
            else:
                prefix = ''.join([w[size] for w in sq])
                matched_words = prefix_cache[prefix] if prefix in prefix_cache else set()
            for word in matched_words:
                candidate_sq = sq[:] + [word]
                self.build_square(candidate_sq, words, word_squares, max_size, prefix_cache)
    
    def get_prefix_cache(self, words, max_size):
        """
        a prefix is a substring from s[:1] to s[:max_size-1]
        map each possible prefix to words that start with that prefix    
        """
        cache = dict()
        for word in words:
            # ex for 'abcd' -> prefix = [a, ab, abc]
            for prefix in (word[:i] for i in range(1, max_size)):
                if prefix in cache:
                    cache[prefix].add(word)
                else:
                    cache[prefix] = {word}
        return cache
                                 
    def wordSquares(self, words):
        if len(words) == 0:
            return []
        
        result = []
        max_size  = len(words[0]) #get size of any word
        prefix_cache = self.get_prefix_cache(words, max_size)
        self.build_square([], words, result, max_size, prefix_cache)
        return list(sorted(result))
