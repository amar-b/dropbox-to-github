"""Given an integer n, return all the strobogrammatic numbers that are of length n.
A strobogrammatic number is a number that looks the same upside down)."""

def findStrobogrammatic(self, n: int) -> List[str]:
    inters = [('0', '0'), ('1','1'), ('8','8'), ('6','9'), ('9','6')] 
    
    def filter_valid(nums):
        return list(sorted([n for n in nums if n[0] != '0' or len(n) == 1]))
    def find(n):
        if n == 0:
            return []
        if n == 1:
            return ['0', '1', '8']
        if n == 2:
            return ['00', '11', '88', '69', '96']
        else:
            mids = find(n-2)
            nums = []
            for mid in mids:
                for l, r in inters:
                    nums.append(l+mid+r)
            return nums

    return filter_valid(find(n))