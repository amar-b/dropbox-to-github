# steps to backup
1) in source broser: copy localstorage object as save as json (dont copy as string . But as object)
2) in dest browser: crete a varible d and set it equals to the object copied 
3) In dst browser: Object.keys(d).forEach(k => localStorage[k] = d[k])
