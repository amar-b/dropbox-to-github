# new console project
dotnet new console -n my_appname

# add package
dotnet add package Newtonsoft.Json --version 12.0.3