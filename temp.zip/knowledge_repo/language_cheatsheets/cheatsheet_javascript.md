# Strings
+ length: `str.length`
+ indexing: `str[idx]`
+ uppercase: `str.ToUpperCase()`
+ lowercase: `str.ToLowerCase()`
+ concat: `str1 + str2`
+ substring: `str.substring()
  + not inclusive end
+ rm whitespace: `str.trim()`

# Numbers
- num to str: `num.ToString()`
- str to num: `Number.parseInt(str, 10)`

# Variables
- `let`: 
  - `1> let x = value`
  - x can be reassigned `2> x= new_value`
  - can redeclare `3> let x = new_val` is an error
- `const`:
  - `1> const x = constant_val`
  - x can't be reassigned `2> x = new_value` is an error
  - value is not nececeriliy immutable. (ex the value can be an object)
  
# selecting elements
- single element `document.querySelector('myCssSelector')`;
  - Returns `Element` object
- all elements `document.querySelectorAll('myCssSelector')`;
    - Returns `NodeList`
    - use `Array.from(nodeList)` to get an array

# element properties
- get id: `el.id`
- class: `el.className`
- tag: `el.tagName`

# element functions
- Add event listerner
  - `el.addEventListener(type, (e) => handle(e))`
- Select sub elements element
  - `el.querySelector(cssSelector)`
# fetch
- `fetch(url, obj) -> Response`
  -  returns a promise that resolves to a Response obj
- `responseObj.json()`
  - returns a promise that resonves to a json object

  ```Javascript
  // get
  fetch(url).then(r => r.json()).then(json => /* do sth */)

  //post
  fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
    .then(resp => resp.json());
  ```
# promises
- `Promise((res, rej) => shit)` takes a function resolve with two parameters that are functions to resolve and reject. 
```JavaScript
p = new Promise((res, rej) => 
  {
    if (n==1)
      return res("Good # " + 1)   // value= `Good # 1`
    else 
      return rej("Error") )       // value = 'Error'
  }

p.then(resolvedValue => resolvedValue)
  .catch(rejectedValue => console.log(rejectedvalue))
```