# String
- `s.split('del')`    - split into list. Optional argument is delimeter
- `s.strip()`         - trim leading and trailing whitespace
- `s.replace(a, b)`   - replace occarances of a with b
- `s.upper()`         - uppercase
- `s.lower()`         - uppercase
- `s.isdigit()`       - true if all chars are digits
- `s.zfill(n)`        - pad with zeros. if `len(s) >= n` no zeros will shpw
- `s.join(lst)`       - join list delimited by s

# iterable
- `sorted(iter, key = lambda x: x)`
- `reversed(iter)`

# list
- `l.sort(key = lambda x: x)`
- `l.reverse()`
- `l1 = list(l2` #copy
- `l.append(val)`
- `l.pop()`
- `l.insert(i, val)`
- `l.remove(val)`
- `l.extend(otherlist)` append a list
- `l.count(val)` number of occurrences of val

# queue (`collections.deque`)
- `q.append(item)`
- `q.popleft()` #first first item inserted



# set
- `s.add(val)`
- `s.remove(val)`
- `s.isdisjoint(o)`
  - check if s an do are disjoint sets
- `s.issubset(o)`
  - check if s is a subset of o
- `n = s.union(o)`
  - create a new set that is union of s and o
- `n = s.intersection(o)`
  - create new set of items that are in both s and o
- `n = s.difference(o)`
  - create new set of items in s but not in o
  
# conversions
- `bin(2)      -> '0b10'`          - decimal to string containing binary. String contains '0b'
- `int('0b10') -> 2`               - binary to decimal
- `ord('a')    -> 97`              - get int for an ascii char
- `chr(97)     -> 'a'`              get ascii char from int

# Indexable[i]
- List, str, tuple

# Hashable
- hashable types can be used as keys in dicts or values in sets
- Lists, sets, dicts are NOT hashable
- ints, bools, strs, floats, tuples and frozensets are hashable
  
# iter
- `iter(list)`
- `iter(str)`
- `iter(tuple)`
- `iter(set)`
- `iter(dict)` 
- `next(iter, default)`
    + default is not a default keyword argument!
    + for dicts next will return they key

# random 
- `random.randint(l, r)` #random int from 1 to r (inclusive)
- `random.choice(arr)` 
- `random.shuffle(arr)`

# math
- `math.floor(x)`
- `math.ceil(x)`
- `math.sqrt(x)`
- `math.log2(x)`
- `math.log(x, base)`
- `math.pi`
- `math.gcd(*numbers)`

# misc
- `type(obj)`
  + `type(1) == int`
  + `type('a') == str` 
  + when used in comparison don't put type in double quotes
    + `'type(1) == int    # True`
    + `'type(1) == 'int'  # False`

# regex
- find group
  ```Python
  import re
  #match return an object if str matches pattern
  m = re.fullmatch('\((\d+)\)(\d+)', '(321)456')

  #get subgrup
  s = re.search('\((\d+)\)(\d+)', '(321)456')
  s.group(1) # 321
  s.group(2) # 456

  # use compile to save time
  comp = re.compile('\((\d+)\)(\d+)')
  s = comp.search('(321)456')
  s.group(1) # 321
  s.group(2) # 456  
  

  ```

