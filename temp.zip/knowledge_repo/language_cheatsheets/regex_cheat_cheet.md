# Regex

## Characters
- `.`  - match 1 char (any char)

- `\d` - match 1 digit from 0-9
- `\D` - match 1 char that is not a digit from 0-9
  
- `\w` - match 1 alphanumeric char or underscore
- `\W` - match 1 char that is not a alphanumeric char or underscore

- `\s` - match 1 space, newline, or carriage return
- `\S` - match 1 char that is on a space, newline, or carriage return

- `[a-zA-Z0-9]` alphanueric

### Repetition
- `x?` match x 0 or 1 times
- `x*` match x 0 or more times
- `x+` match x 1 or more times

- `x{3}` match x exactly 3 times
- `x{3,}` match x exactly 3 or more times
- `x{3,6}` match x exactly 3 to 6 times (inclusive)

### Boundaries
- `^` match start of string
- `$` match end of string

### Logic
- `x|y` match x or y
- `(x)` - capturing group: groups regex inside parans and captures it
  - ex: `(abc){2}(xyz)` matches `abcabxyz` with two groups captured
    + first group matches `abc` two times
    + second group matches `xyz`
- `(?:x)` - non capturing group: groups regex inside parans but no captures
  - ex: `(?:abc){2}(xyz)` matches `abcabxyz`  and one group captured
    - the group matches `xyz`


### Chars need escaping
+ | sign | Desc              |
  |------|-------------------|
  | \    | Backslash         |
  | ?    | question mark     |
  | +    | plus              |
  | *    | star              |
  | .    | period            |
  | \|   | or                |
  | ^    | start carot       |
  | $    | end carot         |
  | ()   | open/close paran  |
  | []   | open/close braket |
  | {}   | open/close curly  |


### Example expressions
- `^-?\d+$` - string is any integer pos or negative
- `\(\d{3}\)\d{3}-\d{3}` - (810)399-6050 phone number format
