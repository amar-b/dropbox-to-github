
## Trie aka prifex tree
- A **prefix** is a substring such that the string starts with the substring
- Special form of mary tree
- used to store strings
- each non root node is a character in a string
- each root nodes points to the first char in each string in the trie
- To distinguish last char is string from other chars, the last chars will have some kind of flag
- All descendants of node share the same prefix (ie they start with the same substring)
- 


