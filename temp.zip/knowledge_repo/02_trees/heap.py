class Heap:
    def __init__(self, array):
        if array:
            self.array = array
            for i in range(len(array)//2 - 1, -1, -1):
                Heap.heapify(array, i) 
        else:
            self.array = []
    
    @staticmethod
    def heapify(array, i):
        n = len(array)
        l = 2*i+1
        r = 2*i+2

        #get i of larger value
        swap_i, max_value = i, array[i]
        if l<n and array[l] > max_value:
            swap_i, max_value = l, array[l]
        if r<n and array[r] > max_value:
            swap_i, max_value = r, array[r]

        if swap_i != i:
            array[i], array[swap_i] = array[swap_i], array[i] #swap so max value is at index i
            Heap.heapify(array, swap_i) #bubble down the smaller value

    def push(self, value):
        self.array.append(value)
        i = len(self.array)-1
        p = (i-1)//2
        #bubble up value if its larger than its parent
        while i > 0: 
            if self.array[p] < self.array[i]:
                self.array[p], self.array[i] = self.array[i], self.array[p]
            else:
                break
            i = p
            p = (i-1)//2

    def peak(self):
        if len(self.array == 0):
            raise Exception("No items")
        return self.array[0]

    def pop(self): #remove highest priority item
        if len(self.array == 0):
            raise Exception("No items")
        n = len(self.array)-1
        self.array[0], self.array[n] = self.array[n], self.array[0]
        val = self.array.pop()
        self.heapify(self.array, 0)
        return val
        
v = [1,2,3,4,5]
h = Heap(v)
print(h.array)
print(h.peak()) #5
h.push(9)
print(h.pop())  #9
h.push(0)
print(h.pop())  #5
print(h.peak()) #4