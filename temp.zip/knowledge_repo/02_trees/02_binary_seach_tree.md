# BST
- A binary tree in which all the nodes j to the left of a node i are smaller i and all nodes to the right of node i are larger
- By definition this implies that a bst has no duplicates
- An in-order traversal of a bst yields a sorted list/array
  + traverse with traverse(lst), visit, traverse(rst) gives reversed array
- Searching for items in a bst takes O(log n)
- complexity:
  + insert 
    - O(n log n) - average 
    - O(n) - worst (when tree is unbalanced)
  + search 
    - O(n log n) - average 
    - O(n) - worst (when tree is unbalanced)
  + traverse
    + O(n)
