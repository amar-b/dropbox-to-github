# Types
## Balanced
- Tree where left side and right subtree of each node differ by a depth of one


## Perfect Binary tree
- Tree where every level is completely filled
- height of a tree is $h = log(n+1)-1$ for a tree with $n$ nodes.
- Thus the number of nodes of a perfect tree of hight $h$ is $n = 2 \times 2^h -1$
- Number of nodes at height $h$ is $2^h$
  + at height 0 there is 1 node
  + at height 1 there is 2^1 = 2 nodes
  + at height 2 there is 2^2 = 4 nodes

## Complete
- balanced with all levels except last level and are completely filled and all leaves in the last level are to left side
- Ex:
```
OG
         1
     1       1
   1   1   1   1

ADD
         1
     1       1
   1   1   1   1
 1 

ADD
         1
     1       1
   1   1   1   1
 1  1 

Add
         1
     1       1
   1   1   1   1
 1  1 1
````