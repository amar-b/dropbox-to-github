class Trie(object):
    def __init__(self, value = '', is_terminal = False):
        self.value = value
        self.children = {}
        self.is_terminal = is_terminal
                
    def insert(self, word):
        """Inserts the string word into the trie."""
        cur = self      
        for char in word:
            if char not in cur.children:
                cur.children[char] = Trie(char)              
            cur = cur.children[char]    
        cur.is_terminal = True

    def search(self, word):
        """Returns true if the string word is in the trie"""
        cur = self
        for char in word:
            if char in cur.children:
                cur = cur.children[char]
            else:
                return False
        return cur.is_terminal
           
    def startsWith(self, prefix):
        """Returns true if the prefix is in the trie"""
        cur = self
        for char in prefix:
            if char in cur.children:
                cur = cur.children[char]
            else:
                return False
        return True
        
            