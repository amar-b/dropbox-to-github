import math

# https://leetcode.com/explore/interview/card/google/61/trees-and-graphs/3067/
def getmax(self, root: Optional[TreeNode]) -> int:
    if root == None:
        return 0
    best_path_sum = 0
    
    # lv, rv = value of best path from left and right subree to current node
    lv, rv, nv = -math.inf, -math.inf, root.val
    
    # brv, blv = value of best path encountered so far in the left and right subrees
    blv, brv =  -math.inf, -math.inf
 
    if root.left:     #recursivly get left subtree values
        lv, blv = self.getmax(root.left)
    if root.right:    #recursivly get right subtree values
        rv, brv = self.getmax(root.right)

    if lv == -math.inf and rv == -math.inf: # if leaf return node value as best path and best value
        return (nv, nv)

    elif lv == -math.inf: # if left subree is null
        val = max(rv+nv, nv) #best path to parent is max of current value or current value plus best path to right
        return (val, max(val, brv))

    elif rv == -math.inf: #if right subree is null
        val = max(lv+nv, nv)
        return (val, max(val, blv))

    else:
        val = max(rv+nv, lv+nv, nv)
        return (val, max(val, brv, blv, nv+lv+rv))

def maxPathSum(self, root: Optional[TreeNode]) -> int:
    return self.getmax(root)[1]
        
        
