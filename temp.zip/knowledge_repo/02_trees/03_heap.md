# Binary heaps
- Binary heaps are binary trees that are [complete](./binary_trees.md##Complete) and satisfy the heap property (ie is max or min heap)
- Used to implement priority queues
- Max heap: binary tree where child nodes always have lower values than parents 
- Min heap: binary tree where child nodes always have larger values than parents
- Typically implemented as an array
    - root node is added is at index `0`
    - To get parent of node at index i is  `(i-1)//2` 
    - left child of node at index i `2*i+1`
    - right child of node at index i `2*i+2`
   
- Non leaf nodes:
    + for a tree of size n
    + non leaf nodes are indexes from `0` to `n/2 -1`
        + thus when building a heap we only need to start from `n/2-1` down to `0`
    
- a sorted array is always a heap
## Complexity
- Push: O(log n)
- Pop: O(log n)
    + top k items O(k log n)
- Peek: O(1)
- Heapify (build heap from array): O(n)
