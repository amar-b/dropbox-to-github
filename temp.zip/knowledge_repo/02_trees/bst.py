class BinarySearchTree:
    """ Each node should be a BinarySearchTree to allow for natural recursion"""
    def __init__(self, value = None, left = None, right = None):
        self.value = value
        self.left = left
        self.right = right

def insert(node, value):
    if node == None:
        return BinarySearchTree(value)
    elif value < node.value:
        node.left = insert(node.left, value)
    elif value > node.value:
        node.right = insert(node.right, value)
    return node

def in_order_traverse(node, arr=[]):
    if node != None:
        in_order_traverse(node.left, arr)
        arr.append(node.value)
        in_order_traverse(node.right, arr)


z = BinarySearchTree(5)
insert(z, 8)
insert(z, 1)
insert(z, 4)
insert(z, 9)
insert(z, 2)

t = []
in_order_traverse(z, t)
print(t)