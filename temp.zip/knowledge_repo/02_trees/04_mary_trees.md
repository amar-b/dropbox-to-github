# M-mary trees
- Height if mary tree with n = $\lfloor log_m  (n(m-1))  \rfloor$