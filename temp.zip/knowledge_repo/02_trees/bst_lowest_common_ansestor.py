"""
Lowest common ancestor of two nodes in a bst
+ if both are smaller than the root then they are both in the lst
+ if both are bigger then they are in the rst
+ if one is larger and one in smaller then the root has to be their common ancestor 
        (regardless of whether they are direct descendants)
"""
def lca(node, v1, v2):
    key = node.info
    if v1 < key and v2 < key:
        lca(node.left, v1, v2)
    elif v1 > key and v2 > key:
        lca(node.right, v1, v2)
    else:
        return node

