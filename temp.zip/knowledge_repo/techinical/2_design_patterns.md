# Design patterns

## 1) Creational - patterns that deal with object creation

### Factory Method
- defines an interface for creating an object but lets subclasses decide which class to instantiate
- factory method is abstract so subclass do actual instantiating
- ideally the factory method should return an abstract/base product
- specialization of template pattern that only does instantiation

### Abstract Factory
- Defines an interface for creating families of products
- Concrete factories implement all the methods for creating the products

### Singleton
- Ensure there is a single instance
- Use private constructor and public static method to return instance
- Consider thread safety and lazy instantiation

-----------------
## 2) Structural - focuses ways to compose and layer abstractions

### Decorator
- Attach additional behaviors to objects dynamically
- Decorator class implements the same interface as class it wraps around. Class it wraps around (using composition) is a private field.
- By implementing same interface we can modify or replace behavior of class it wraps around
- Provide an alternative to subclassing for extending functionality

### Facade
- Decouples the client from a complex system by exposing a simple interface
- We compose the facade with the subsystem and use delegation to do work

### Adaptor
- Converts the interface of a class to another interface that the client expect
- We compose the adaptor with the unwanted interface and have the facade extend/inherit from the desired interface

-----------------
## 3) Behavioral - identifies common communication patterns between objects
### Strategy
- Defines a family of algorithms and makes them interchangable using a common interface. 
- Clients use the the algorithms using composition 
- Algorithms can vary from clients that use them
- Example flying duck behavior

### Observer (-Pubsub)
- Publisher has a list of subscribers and notifies them when a change happens to it
- In pubsub there is an even broker between the publisher and subscriber. So publisher publishes topics and don't know who the subscribers are. Even broken is in charge of grouping the messages by topics and notifying the subscriber.

### Command
- Decouple object making the request from one that uses it (invoker and receiver)
- Uses a command object encapsulates a receiver object's specific actions and exposes an `execute()` method. This method is what triggers the execution of the receiver's actions.
- The invoker has a `setCommand` method takes a command object as an argument.
- At some later time the invoker evokes the `execute()` method which results in actions being invoked on the receiver.
- THe command can also have a `undo` method which reverses the actions done in the `execute)_`

### Template
- Define a skeleton of an algorithm while deferring some steps to subclasses.

### Iterator
- Provide a way to iterratite on elements of an aggregate object without exposing the underying representation of the aggregate.
- The task of iteration gets placed on the iterator object so the aggregate doesn't need to focus on interation (single resonsibilty!)
### Composite

---------------------------
# Design principle
- Encapsulate what varies
- Favor composition over inheritance
- Program to interfaces not implementations
- Strive for loosely coupled designs between objects that interact
- Open closed principle - classes should be open to extension but closed to modification
- Dependency inversion principle - depend on abstractions not concrete classes
- Principle of least knowledge - Only talk to your immediate friends (don't dot fifty times)
- Hollywood principe - don't call us we'll call you