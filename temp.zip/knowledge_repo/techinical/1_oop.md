# 4 principles of object oriented programming
4 principles are

1. Abstraction 
  - Hiding unnecessary details. 
  - This allows clients to add complex logic on top of thing you're abstracting without the clients knowing or caring about its implementation details

2. Encapsulation 
  - Insulating the internal state or functionality of an object and only allowing access through public interfaces

3. Inheritance 
  - Ability of abstractions be be derived from other abstractions
  - This creates a hierarchy of characteristics where common characteristics are at higher levels than unique characteristic
    
4. Polymorphism - ability to present the same interface to different types
  - Static
      + Example is list operations in many programming languages. You perform add or remove operations on lists of any time
      + Another example is like a addition for some calculator class. Though polymorphism you can make addition work for both integers and floating point numbers but using overloading
  - Dynamic
      + Two classes using the same interface or coming from the same inheritance hierarchy can have different implementations for the same method signature
      + overrudubg


# Solid
- Single responsibility 
  - Class should have one responsibility. 
  - Split the class if it does more than one unrented thing. Should be cohesive
  - Example a class that makes a class to an api shouldn't also open connections to the database
  
- Open Closed
  - Class should be open to extension but close to modification
  - Example is using inheritance to extend functionality of an abstract  or decorator pattern to add more functionality to a concrete class

- Liskov Substitution 
  - subclass/implementation should be able to replace a superclass/interface without breaking the functionality. In other words subclass should not break the contract set by the superclass

- Interface segregation 
  - Better to have multiple interfaces than a giant interfaces that forces implementation
  
- Dependency inversion 
  - This is achieved with good abstraction. Its form of decoupling where high level code should not dependent on low level code they are both dependent on abstractions
  - If class ClassA (higher level component) calls some method of ClassB that means it depends on an implementation. ClassA should only depend an abstraction. To do this ClassB should implement and thus be dependent on interfaceB and ClassA should be coded to InterfaceB (ie coded to an abstraction not a implementation.
  - Can achieve interface inversion using open-closed and liskov substitution 
    - By using interfaceB the interface is open to extension but closed to modification
    - By replacing ClassB with interfaceB we are using liskov substitution.


  
# KISS - keep it simple stupid
- Basically is writing code in a straightforward and easy to read matter. The focus should be finding the solution, not over- engineering


# DRY
- Don' repeat yourself
- avoid bloat and duplicate code


## Quality metrics
- Coupling: Measure of inter-dependence between components. Loose coupling is good
- Cohesion: Measure of gow single purposed and well defined each component is. High cohesion is good
- Cyclomatic complexity - How complex a components' control flow is. Strive for low cyclomatic complexity.