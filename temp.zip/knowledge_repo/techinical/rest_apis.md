# Definitions
## API
- is like a contract to allows clients/consumers to retrieve data or perform some operation on the data in your system or possibly more downstream system.

## [RESTful Api](https://restfulapi.net/)
- A set of architectural constraints for designing loosely coupled applications over the network
    1. Uniform interface: A uniform interface to allow interaction b/w client and server
    2. Client-server: Must be independent of each other
    3. Stateless
    4. Cache-able
    5. Layered system: Client cannot ordinarily tell if its connected to end server or an intermediary  along the way
        + intermediary can be a bff, proxy or load balancer)
    6. Code on demand (optional)
- A restful api is a http api that that satisfies the REST architectural constraints

## Http apis?
- Any API that uses http as its transfer protocol
- So http apis are not always restful
- ex: "rest like" http api that uses cookies or caching making it stateful so its not really/fully restful
- ex: soap api are http apis a


# Http Methods
- `GET /tickets` 
    - Gets list of all tickets
    - Use pagination if response is too large

- `GET /tickets?location=mi&type=vip` 
    - Gets list of all tickets where `location = mi` and `type = vip`
    - Use pagination if response is too large

- `GET /ticket/12`
    - Get ticket with `ticket_id=12`

- `POST /ticket`
    - Creates new ticket from request body (typically json body)
    - Typically returns a `201` 
    - Returns the created entity in the resource to avoid another call

- `PUT /ticket/12`
    - Fully update the ticket with `ticket_id=12` from request body (typically json body)
    - Returns the updated entity in the resource to avoid another call

- `PATCH /ticket/12`
    - Partially update the ticket with `ticket_id=12` from request body (typically json body)
    - Returns the updated entity in the resource to avoid another call

- `DELETE /ticket/12`
    - Delete ticket with `ticket_id=12`

- `OPTIONS`

# Authentication 
- Rest apis should be stateless, so authentication should not be based on cookies or session
- Basic auth
    `Basic btoa(my_username:my_password)`
- Token-based auth
    `Bearer my_access_token`

# Status Codes
- `200 OK` 
    - Successfully GET/PUT/PATCH/DELETE. 
    - Can also be used for POST That doesn't result in a creation

- `201 Created` 
    - Response to a POST that results in a creation
    - Accompanied with with a `Location` header pointing the the location of the new resource 
        + In case of SPA this is not needed since the uri doesn't change

- `204 No Content`
    - Response toa successful request that won't be returning a body
    - Ex: a a DELETE request or a simple patch request

- `400 Bad Request`
    - Request is malformed or not valid

- `401 Unauthorized`
    - Invalid authentication details

- `403 Forbidden`
    - Authenticated but not authorized to make request

- `404 Not Found`
    - When a non-existent resource is requested

- `429 Too Many Requests`
    - Request is rejected due to rate limiting

- `500 Internal server error`
    - Some unknown server error

- `502 Bad Gateway`
    - Server not able to get the response from another upstream server