# Recursive:
- Recurse $n - c$ times -- $O(n)$
  ```Python
  def r(arr):
    if len(arr) <= 0:
      return 1
    else:
      return 1 + r(arr[1:])

  def r2(n):
    if n <= 0:
      return 1
    else:
      return 1 + r2(n-1)

  def r3(n):
    if n <= 0:
      return 1
    else:
      return 1 + r2(n-10)
  ```

- Recurse but reduce input size by $c$ -- $O(log_c n)$
  ```Python
  def r(arr):
    mid = len(arr)//2
    if mid <= 0
      return 1
    else:
      return 1 + r(arr[mid:]) #

    def r2(n):
      if n <= 0:
        return 1
      else:
        return 1 + r2(n/2)
  ```

- Each recursive calls itself $c$ to,es -- $O(c^n)$
  ```Python
  def r(n):
    if n <= 0:
      return 1
    else:
      return r(n-1) + r(n-2)
  ```

- Tree traversal - O(n)
  + just visit each node

- recursive dfs - O(V+E)
