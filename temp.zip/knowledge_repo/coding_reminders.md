# Math shit

------------- 

## Floors and ceilings
- For any number $x$,
  - the greatest integer less than or equal to  $x$ is $floor(x)$
  - the greatest number less than or equal to $x$ is $ceil(x)$
  - $floor(-x) = - ciel(x)$, $ciel(-x) = -floor(x)$
  - For all any integer $x$, $floor(x/2) + ceil(x/2) = x$
-------------

## Modular
- $a \% n = a$ if $n>a$
- Mods "wrap around"
   -  `1%3=3,  2%3=2, 3%3=0, 4%3=1, 5%3=2, 6%3=0 ....`
- $n \% 10 $ will always get the lst digit of x 

-------------

## Factorials
- $0! = 1$
- $x! = x \times (x-1)!$
- [Python Impl](./math_algos/factorial.py)
-------------

## Fibonanocci numbers
- $Fib(0)=1$
- $Fin(1)=1$
- $Fib(x) = Fib(x-1)+Fib(x-2)$
- [Python Impl](./math_algos/fibonacci.py)
-------------
## Factors/Divisor
- A number that divides another number and leaves no reminder 
  - 2 factors multiplied make up a product (or multiple)
  - So a factor is always less than or equal to the the product (is equal to when the second factor is 1)
  - Ex factors of 20: 1,2,4,5,10,20
  - $a$ is a factor of $b$ iff $a\%b=0$
- a factor of $n$ can't be larger than $n/2$ unless the factor is also $n$
    + intuitively a factor can be 1 or 2 but not 1.5

-------------------------

## Prime numbers
- 2, 3, 5, 7, 11, 13 +
- A number $n$ is prime iff
  1. $n$ is not $1$
  2. $n$ has no factors other than $1$ and itself
- Alternative definition: A number is prime if
  1. its 2 or 3
  2. it has the from $6n \pm 1$
- [Python Impl](./math_algos/is_prime.py)

-------------------------

## Common factors/divisors (GCF/GCD and LCF/LCD)
- The common factors (or divisors) of $x$ and $y$ are all the numbers that numbers that are factors of $x$ and also factors of $y$
- Gcf/Gcd is the largest common factor. 
- Lcf/Lcd is the smallest common factors
- Ex: common factors of 12 and 16
  + factors of 12: 1,2,3,4,6,12
  + factors of 16: 1,2,4,8,16
  + common factors: 1,2,4
  + gcf/gcd: 4
  + lcf/lcd: 1

### Euclidean algorithm
- An efficient way of computing the gcd
- Steps: find the gcd of a and b
    1. If $a<b$, swap a and b so that b becomes smaller than a
    2. Divide a by b and get the remainder, r. Ie find $r = a\%b$
    3. If $r=0$, then $gcb = r$ else go to step 4
    4. Set $a=b$ and $b=r$. 
    5. Repeat to to step one
- [Python implementation](./math_algos/gcd_euclidian_algorithm.py)

### LCM from GCF/GCD
- $lcm(a,b) =  \frac{a \times b} {gcd(a, b)} $

-------------------------

## Triangular numbers: $1+2+3+4 + \dots $ - T
- $\sum_{k=1}^{n} k = \frac{n(n+1)}{2}$

-------------------------
# Counting shit
## Rule of Sums and products
- Sometimes we can expre the things we want to count as s union of disjoint sets or as a catecian product of sets

### Rule of sums:
  - The number of ways to choose 1 element from any set in a group of disjoint sets is the sum of cardinalities of the disjoint sets
  - Ie number of ways of selecting an item from any of the disjoint set
  - Ex: Number of possible letters in a lisece plate is the sum of cardialities of letter set (A-Z) and the number set (0-9). So there are 26+10=36 possible choices

### Rule of product: 
- The number of ways to chose an *Ordered pair* is the number of ways to choose the first element times the number of ways to choose the second element.
  - Ie number of ways of selecting one item from each set
  - Ex: Icecream shop offers 28 flavors nd 4 topping. There are 28 possible flavors and for each flavor there are 4 possible toppings. Thus there are 28*4=112 possible sundaes with one scoop and one topping

### k-Strings
- Basicity applies rule of product to the same set
- A string over a set $S$ is the a sequence of elements in $S$. 
- The cardinality $|S|$ is the number of characters that can be in a string. For a string of size $k$, there are $|S|^k$ ways to construct. This is a cartesian product
- There are $|S|$ ways to choose $char_1$, and for each $<char_1>$ there are $|S|$ ways to chose $char_2$, and for each $<char_1, char_2>$ there are $|S|$ ways to choose char3

### Permutation
- A permutation of set $S$ is an ordered sequence of all elements of $S$ with each element appearing once
- Order does matter
- For $|S|=n$, there are $n!$ permutations. Ie there are $n!$ ways for of arranging the items in $S$
  - $n$ ways to choose first element, $n-1$ to choose the second and so one.
- A k-permulation is a permutation where the sequence size is $k$. Ie ways of choosing a a subst
  - For $k=n$, there are $n!$ permulations
  - For $k<n$, there are $n!/(n-k)!$ k-permutations 
- In programming the permutation of a string is a rearrangement of items in a string
- Ex1: GIven a set of all 16 billiard balls, what are the different ways of arranging them
  + Initially there are n=16 possibilities, but after choosing a ball there are 15 possibilities, etc. 
  + Answer: $n!$
- Ex2: What are the ways of selecting just 3 balls?
  + ans $16!/(16-3)!$

### Combination
- A k-combination of $S$ is a sequence of all subsets of $S$ of size $k$. 
- Order doesn't matter


### https://www.mathsisfun.com/combinatorics/combinations-permutations.html

-------------------
# Computer shit

## Bits, bytes, and conversions
- Bit/Byte conversions
  + ```
    1 byte = 8 bits
    1024 bytes = 1 kb = 8 kilobits
    1024 kb = 1 mb = 8 megabits
    1024 mb = 1 gb = 8 gigabits
    ```

- 1 Hex digit = 4 bits
  - ex `0xF1 = 1111 0001`

- Decimal to binary
  + ```
      1 = 0001
      2 = 0010
      3 = 0011
      4 = 0100
      ```
  - `bin(int)`to get bin from int and `int(str, 2)` to get int from bin

- Ascii characters
  - Each character is 1 byte (8 bits wide)
  - Standard set has 128 characters, and is has a zero index
    - Range = `hex=0x00 decimal=0` to `hex=0x7F decimal=127`
  - Python
    + `ord(char) -> int`
    + `chr(int) -> char`

- 32 bit integers:
  + range = $\left[ -2^{31},  2^{31} -1 \right]$
