import random

def partition_random(arr, l, r):
  random_idx = random.randint(l, r) #inclusive range

  #move random pivot towards end so it works with partition()
  arr[r], arr[random_idx] = arr[random_idx], arr[r] 

  return partition(arr, l, r)

def partition(arr, l, r):
  piv = arr[r]          # set pivot as last item. 
  piv_ptr = l           # final index of pivot initialized to l
  for i in range(l, r): # iterate over all items other than last
    if arr[i] <= piv:
      # increment piv_ptr, swap item leq piv to be left of piv_ptr
      arr[i], arr[piv_ptr] = arr[piv_ptr], arr[i]
      piv_ptr +=1
  arr[piv_ptr], arr[r] = arr[r], arr[piv_ptr] #move piv to final pos
  return piv_ptr
   
def quick_sort(arr, l, r):
  if (l >= r):
    return arr
  piv = partition_random(arr, l, r)
  # note: all items left to piv are now leq piv and piv is in pos
  quick_sort(arr, l, piv-1)
  quick_sort(arr, piv+1, r)
  return arr
  

if __name__ == '__main__':
  arr = [8,9,0,1,4,7, -1]
  r = quick_sort(arr, 0, len(arr)-1)
  print(r)