# Find minimal items and put in in the beginning/final pos
def selection_sort(arr):
  n = len(arr)
  for i in range(n):  # <i are indexes of sorted part of array
    min_idx, min_val = i, arr[i]
    for j in range(i+1, n):
      if arr[j] < min_val:
        min_idx, min_val = j, arr[j]
    arr[i], arr[min_idx] = arr[min_idx], arr[i]
  return arr

r = selection_sort([8,9,0,1,4,7])
print(r)