def insertion_sort(array):
	n = len(array)
	for i in range(1, n):
		key = array[i]
		j = i
		while j-1 >= 0 and key < array[j-1]:
			j = j -1
			array[j+1] = array[j]
		array[j] = key
	return array
		
s = insertion_sort([1,5,4,3,0])
print(s)
