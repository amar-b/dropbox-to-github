def _counting_sort(arr, place):
  k = 10
  n = len(arr)
  counts = [0]*k
  out = [0]*n

  for i in range(n):
    val = arr[i]
    digit = (val // place) % k
    counts[digit] += 1

  for i in range(1, k):
    counts[i] += counts[i-1]

  for i in range(n-1, -1, -1):
    val = arr[i]
    digit = (val // place) % k
    counts[digit] -= 1
    out[counts[digit]] = val

  return out

def radix_sort(arr):
  max_value = max(arr)

  place = 1
  while max_value // place > 0:
    arr = _counting_sort(arr, place)
    place *= 10

  return arr

  

if __name__ == '__main__':
  arr =[121, 432, 564, 23, 1, 45, 788]
  print(radix_sort(arr))