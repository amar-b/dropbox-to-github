def merge_sort(array):
	if len(array) > 1:
		midpoint = len(array)//2
		left = merge_sort(array[:midpoint])
		right = merge_sort(array[midpoint:])
		array = _merge(array, left, right)
	return array
	
def _merge(array, left, right):
	a = l = r = 0
	while l<len(left) and r<len(right):
		if left[l] <= right[r]: #equals to is needed to maintain stability
			array[a] = left[l]
			l+=1
		else:
			array[a] = right[r]
			r+=1
		a+=1 
	while l<len(left):
		array[a] = left[l]
		l+=1
		a+=1
	while r<len(right):
		array[a] = right[r]
		r+=1
		a+=1
	return array
		
r = merge_sort([8,9,0,1,4,7])
print(r)
