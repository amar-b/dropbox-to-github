
"""Basicity get largest value for heap and put it towards the right and fix the right side"""
def heap_sort(array):
  n = len(array)

  #build heap
  for i in range(n//2 -1, -1, -1):
     _heapify(array, n, i)
  
  #get max item and put it in final position
  for i in range(n-1, -1, -1):
    array[i], array[0] = array[0], array[i]
    _heapify(array, n=i, i=0) #i=len of array without element(s) at index i or more
  
  return array

def _heapify(array, n, i):
    """Assumes left and right subtrees are heapified"""
    l = 2*i+1
    r = 2*i+2

    #get i of larger value
    swap_i, max_value = i, array[i]
    if l<n and array[l] > max_value:
        swap_i, max_value = l, array[l]
    if r<n and array[r] > max_value:
        swap_i, max_value = r, array[r]
    
    # put larger value at index i. Bubble down the smaller value
    if swap_i != i:
        array[i], array[swap_i] = array[swap_i], array[i]
        _heapify(array, n, swap_i)

    

array = [5, 3, 4, 2, 1, 0, -1]
print(heap_sort(array))

