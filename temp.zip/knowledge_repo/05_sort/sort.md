# MOst common in interviews are quick, merge, and bucket (radix) sort
- [Bubble](./bubble.py) - O(n^2) 
  + O(n) if sorted/nearly sorted
  - stable

- [Selection](./selection.py) - O(n^2)
  + mostly useless
  + Not stable

- [Insertion](./insertion.py) - O(n^2)
  + O(n) if sorted/nearly sorted
  + stable

- [Merge](./merge.py) - O(nlogn)
  + guaranteed O(nlogn)
  + Not in place (requires extra space)
  + stable

- [Heap](./heap.py) - O(nlogn)
  + guaranteed O(nlogn)
  + not stable

- [Quick](./quick.py) - O(nlogn)
  + O(n^2) worst case
  + not stable

- [Counting](./counting.py) - O(k + n)
  + Where k is largest number in array
  + can only be used when array contains nonnegative integers
  + fastest when k < n
  + Must be a stable sort (to help Radix sort)

- [Radix](./radix.py) - O(d(n+10)) = O(dn)
  + where d is the number of calls to counting sort ie max number of digits in array  - len( str( max(arr) ) )
  + Counting not good when k=n^2 but radix sort handles this case 

