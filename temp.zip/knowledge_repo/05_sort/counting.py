def counting_sort(arr):
  n = len(arr)
  k = max(arr)+1

  out = [0]*n
  counts = [0]*k

  # counts[x] = number of times value x appears in arr
  for i in range(n):
    val = arr[i]
    counts[val] += 1

  # counts[x] = number of values less than or equal to x
  for i in range(1, k):
    counts[i] += counts[i-1]

  for i in range(n-1, -1, -1):
    val = arr[i]
    counts[val] -= 1
    out[counts[val]] = val
  return out

if __name__ == '__main__':
  arr = [9, 1, 4, 7, 1, 2, 7, 5, 2]
  print(counting_sort(arr))