def bubble_sort(array):
  """bubble up largest value and put it in end/final position"""
  n = len(array)
  for i in range(n): # >= (n-i) are indexes of sorted part of array
    # bubble up largest value in unsorted part of array
    for j in range(1, n-i):
      if array[j-1] > array[j]: 
        array[j-1], array[j] = array[j], array[j-1]
  return array

def bubble_sort_sorted(array):
  """Allows for best case of O(n) when list is sorted"""
  n = len(array)
  is_sorted = True
  for i in range(n):
    for j in range(1, n-i):
      if array[j-1] > array[j]: 
        is_sorted = False
        array[j-1], array[j] = array[j], array[j-1]
    if is_sorted:
      break
  return array
  
r = bubble_sort_sorted([8,9,0,1,4,7])
print(r)