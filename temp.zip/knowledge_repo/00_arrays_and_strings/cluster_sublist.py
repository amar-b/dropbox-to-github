def matches(word1, word2):
  return word1 == word2

"""Givin a list of words cluster words that match each other."""
def cluster(words):
  clusters = [ [words[0]] ]

  for i in range(1, len(words)):
    word = words[i]
    is_added = False

    # Add word to cluster that matches it
    for c in clusters:
      if matches(word, c[0]):
        c.append(word)
        is_added = True
        break

    # Create new cluster
    if not is_added:
      clusters.append([word])
  return clusters
      
words = ['a', 'b', 'c', 'a', 'c']
print(cluster(words))