""" Count number of deletions needed to make a and b anagrams (ie permutations of one another)
ex: 
A = cde
B = abc

need to remove d & e from A and a & b from B, to make A and B anagrams so 4 deletions needed
"""
def makeAnagram(a, b):
    d = {}
    
    # if values for a character in d are not 0 then it means that its in a and not in be or vice versa
    for letter in a:
        if letter in d:
            d[letter] += 1
        else:
            d[letter] = 1
    for letter in b:
        if letter in d:
            d[letter] -= 1
        else:
            d[letter] = -1 
             #not +1 because if the letter apparas again in b then it the value in d[b] will be 0 when it should be -2
    
    # count the number of removals
    removals = 0
    for k,v in d.items():
        removals += abs(v)
    return removals
            