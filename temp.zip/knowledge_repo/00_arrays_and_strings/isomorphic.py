def is_isomorphic(word1, word2):
  """determine it two words are isomorphic"""
  if len(word1) != len(word2):
    return False

  d = {}
  d2 = {}
  for i in range(len(word1)):
    char1 = word1[i]
    char2 = word2[i]

    if char1 in d:
      old = d[char1]
      if old != char2:
        return False
    else:
      d[char1] = char2

    if char2 in d2:
      old = d2[char2]
      if old != char1:
        return False
    else:
      d2[char2] = char1

  return True
  
print(is_isomorphic("zaz", "xyx"))