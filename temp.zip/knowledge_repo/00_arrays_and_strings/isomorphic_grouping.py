def get_conn(word):
# get the canonical representation of the word
  o = ord('a')
  conn_char = dict()
  conn_word = ''

  for char in word:
    if char not in conn_char:
      mapped_char = chr(o)
      conn_char[char] = mapped_char
      conn_word += mapped_char
      o += 1
    else:
      conn_word += conn_char[char]
  return conn_word

def group_isomorphic(words):
  """O(N*M + N) = O(M*N)
    O(N*M) to generate word_to_con dict
    O(N) to cluster words
  """
  word_to_con = {word: get_conn(word) for word in words} #word to conn words

  clusters = {} #maps each conn word to a list of words
  for word in words:
    conn_word = word_to_con[word]
    if conn_word not in clusters:
      clusters[conn_word] = [word]
    else:
      clusters[conn_word].append(word)
  
  return [list(v) for v in clusters.values()]


print(get_conn("llmmnn"))
print(get_conn("xxyyxx"))