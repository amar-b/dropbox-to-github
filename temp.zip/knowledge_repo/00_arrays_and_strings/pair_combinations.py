""" Gets all pair combinations of items
    ex: arr = [1,2,3,4]
    ---- pairs -------
    (1,2) (1,3) (1,4)
          (2,3) (2.4)
                (3,4)
"""
def pair_combinations(arr):
    n = len(arr)
    pairs = []
    for i in range(n):
        for j in range(i+1, n):
            pairs.append((arr[i], arr[j]))
    return pairs

print(pair_combinations([1,2,3,4]))