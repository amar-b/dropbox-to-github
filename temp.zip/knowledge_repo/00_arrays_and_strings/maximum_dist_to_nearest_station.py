import math

"""
n = number of cities. Each city is numbered from 0 to n-1
c = list of cities with stations. Assume there is one city in c
Distance to the next city to the left of city i that has a station
    1. math.inf if no city to left
    2. 0 if city i has station
    3. i - prev_c where prev_c is city to left
Distance to the next city to the right of city i that has a station
    1. math.inf if no city to right
    2. 0 if city i has station
    3. next_c - i where next_c is next city to right
For each city i determine the distance of closest station
Then find the largest distance to the nearest station

Example inputs
https://www.geeksforgeeks.org/find-maximum-distance-between-any-city-and-station/
https://www.hackerrank.com/challenges/flatland-space-stations/problem?h_r=internal-search
"""
def largest_dist_to_nearest_stations(n: int, c: list):
  """O(c log c + n) fast when c is small and slow when c~n"""
  if len(c) == n:
    return 0  #avoid sorting if each city has a station

  c_iter = iter(sorted(c))
  prev_c = -1
  next_c = next(c_iter,-1)

  max_dist = -1
  for city in range(n):
    if city == next_c:
      max_dist = max(max_dist, 0)
      prev_c = next_c
      next_c = next(c_iter, -1)
    else:
      l = math.inf if prev_c == -1 else city-prev_c
      r = math.inf if next_c == -1 else next_c-city
      dist_nearest_station = min(l,r)
      max_dist = max(max_dist, dist_nearest_station)

  return max_dist