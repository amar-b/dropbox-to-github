### Adjacent pairs in a grid (top bottom, diagonals)
And mxn grid can be divided into corner, edge, and interior cells
  + Corner cells
    + there are 4 corner cells.
    + Each touches 3 cells including diags
    + Each touches 2 cells not included diags

  + Edge cells
    + There `2*(m-2) + 2*(n-2)` edge cells
      + perimeter of as rectangle `2l + 2w`, but length of each side reduced by 2 due to the corners cells
    + Each touches 5 cells including diags
    + Each touches 3 cells not included diags


  + Interior cells:
    + There are `(m-2) * (n-2)` interior cells
      + Area of rectangle is `l * w`, but length of each side reduced by 2 due to edge cells and corners
    + Each touches 8 cells including diags
    + Each touches 4 cells not included diags

  + For a mxn grid:
    + There are `3*4 + 5*(2*(m-2) + 2*(n-2)) + 8*(m-2)*(n-2)` adjacent pairs inc diags
    + There are `2*4 + 3*(2*(m-2) + 2*(n-2)) + 4*(m-2)*(n-2)` adjacent pairs not inc diags


### Black & white squares in a checkered $n \times n$ grid
  - If n is even: each color has exactly $n^2/2$ squares
  - if n is odd: then one is $floor(n^2/2)$ and other is $n^2 - flloor(n^2/2)$