""" Generates all possibly n! permutations for array of size n"""
def permutations(arr):
    perms = []
    _permute(arr, 0, perms)
    return perms

def _permute(a, left: int, list: arr):    
    # left serves as barrier so items with index lesser than left are "fixed" and can't be swapped
    # initially left is 0
    # rec tree image" https://media.geeksforgeeks.org/wp-content/cdn-uploads/NewPermutation.gif

    n = len(a)
    if left==n: 
        arr.append(a[:])
    else: 
        for i in range(left, n): 
            a[left], a[i] = a[i], a[left]   #swap item with index i with item with index left
            _permute(a, left+1, arr)       #only items with index left+1 will ever 'move' (and 'move back' see below)
            a[left], a[i] = a[i], a[left]   #every item swapped gets returned (this is recursively true)
    return


perms = permutations([1,2,3,4])
l = 0
for perm in perms:
    print(perm)
    l +=1
print('permutations', l)
