#rotate right
def rotate(arr, k, rotate_func):
  n = len(arr)
  cur_idx = 0
  cur_val = arr[cur_idx]

  while True:
    next_idx = rotate_func(cur_idx, n)
    next_val = arr[next_idx]

    arr[next_idx] = cur_val
    
    cur_idx = next_idx  
    cur_val = next_val

    if cur_idx == 0: #if back to start break
      break
  return arr
    
def rotate_right(arr, k):
  n = len(arr)
  if k > n:
    k = k%n

  func = lambda i,n: i+k if i+k < n else i+k-n
  return rotate(arr, k, func)

def rotate_left(arr, k):
  n = len(arr)
  if k > n:
    k = k%n

  func = lambda i,n: i-k if i-k >=0 else n+(i-k)
  return rotate(arr, k, func)

print(rotate_left([1,2,3,4,5],1))