"""Finds chunks of size k for adjacent items in an array. Finds chunks of from k=1 to k=n-1 where n is the array size
    ex: arr = [1,2,3,4,5]
    --- k = 3 ---
    [1,2,3]
    [2,3,4]
    [3,4,5]
    --- k = 4 ---
    [1,2,3,4]
    [2,3,4,5]
"""

def k_adjacent_items(arr):
    print('Full', arr)
    n = len(arr)
    chunk_size = 1
    i = 0
    while chunk_size <= n:
        while i+chunk_size <= n:
            chunk = arr[i:i+chunk_size]
            print(f'k = {chunk_size}', chunk)
            i += 1

        chunk_size += 1         #increase chunk size
        i = 0                   #reset pointer

k_adjacent_items(list(range(5)))