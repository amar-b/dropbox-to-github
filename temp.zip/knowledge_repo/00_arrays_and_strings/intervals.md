# Intervals- dfdsf
- Two dermine if two intervals overap
  - sort intervals to obtain a and such that a starts before b
  - the intervals overlap if end of a is after than start of b
    - a[1] >= b[0]
    - we also know by sorting that a[0] <= b[0]

- two determine if three intervals overlap
- sort intervals to obtain a, b and c such that a starts before b and b starts before 3
- the 3 intervals overlap if end of a is after start of b and c and the end of b is after the start of c

- Given n overlapping intercals

```Python
from collections import Counter
class MyCalendarTwo:
    def __init__(self):
        self.d = Counter()
        
    def book(self, start: int, end: int) -> bool: #check if 3 intervals overlaps
        self.d[start] +=1
        self.d[end] -=1
        acc = 0
        for k in sorted(self.d):
            acc += self.d[k]
            if acc > 2:
                self.d[start] -= 1
                self.d[end] +=1
                return False
        return True
```